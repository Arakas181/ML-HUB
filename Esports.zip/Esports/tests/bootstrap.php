<?php
/**
 * PHPUnit Bootstrap File
 * Sets up testing environment for Esports Platform
 */

// Set error reporting for tests
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set timezone
date_default_timezone_set('UTC');

// Define constants for testing
define('APP_ENV', 'testing');
define('TEST_ROOT', __DIR__);
define('PROJECT_ROOT', dirname(__DIR__));

// Include Composer autoloader
require_once PROJECT_ROOT . '/vendor/autoload.php';

// Include project files
require_once PROJECT_ROOT . '/config.php';
require_once PROJECT_ROOT . '/includes/SecurityMiddleware.php';
require_once PROJECT_ROOT . '/includes/CacheManager.php';

/**
 * Test Database Helper
 */
class TestDatabaseHelper {
    private static $pdo;
    private static $initialized = false;
    
    public static function getInstance() {
        if (!self::$initialized) {
            self::initializeTestDatabase();
        }
        return self::$pdo;
    }
    
    private static function initializeTestDatabase() {
        $host = getenv('DB_HOST') ?: 'localhost';
        $dbname = getenv('DB_NAME') ?: 'esports_platform_test';
        $username = getenv('DB_USER') ?: 'root';
        $password = getenv('DB_PASS') ?: '';
        
        try {
            // Create test database if it doesn't exist
            $tempPdo = new PDO("mysql:host=$host", $username, $password);
            $tempPdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
            
            // Connect to test database
            self::$pdo = new PDO(
                "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
            
            self::setupTestTables();
            self::$initialized = true;
            
        } catch (PDOException $e) {
            throw new Exception("Test database connection failed: " . $e->getMessage());
        }
    }
    
    private static function setupTestTables() {
        $schema = file_get_contents(PROJECT_ROOT . '/database_schema.sql');
        
        // Split schema into individual statements
        $statements = array_filter(
            array_map('trim', explode(';', $schema)),
            fn($stmt) => !empty($stmt) && !str_starts_with($stmt, '--')
        );
        
        foreach ($statements as $statement) {
            if (trim($statement)) {
                self::$pdo->exec($statement . ';');
            }
        }
    }
    
    public static function truncateAllTables() {
        $tables = [
            'security_logs', 'rate_limits', 'csrf_tokens',
            'tournament_participants', 'matches', 'tournaments',
            'squad_members', 'squads', 'users', 'teams',
            'cache_data', 'notices', 'content'
        ];
        
        self::$pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        
        foreach ($tables as $table) {
            try {
                self::$pdo->exec("TRUNCATE TABLE $table");
            } catch (PDOException $e) {
                // Table might not exist, continue
            }
        }
        
        self::$pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    }
    
    public static function seedTestData() {
        // Create test users
        $users = [
            ['id' => 1, 'username' => 'testuser', 'email' => 'test@example.com', 'password' => password_hash('password', PASSWORD_DEFAULT), 'role' => 'user'],
            ['id' => 2, 'username' => 'testadmin', 'email' => 'admin@example.com', 'password' => password_hash('password', PASSWORD_DEFAULT), 'role' => 'admin'],
            ['id' => 3, 'username' => 'testsuperadmin', 'email' => 'superadmin@example.com', 'password' => password_hash('password', PASSWORD_DEFAULT), 'role' => 'super_admin']
        ];
        
        $stmt = self::$pdo->prepare("
            INSERT INTO users (id, username, email, password, role)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        foreach ($users as $user) {
            $stmt->execute(array_values($user));
        }
        
        // Create test tournaments
        $tournaments = [
            ['id' => 1, 'name' => 'Test Tournament 1', 'description' => 'Test Description', 'start_date' => '2024-01-15', 'end_date' => '2024-01-20', 'created_by' => 2],
            ['id' => 2, 'name' => 'Test Tournament 2', 'description' => 'Test Description 2', 'start_date' => '2024-02-15', 'end_date' => '2024-02-20', 'created_by' => 2]
        ];
        
        $stmt = self::$pdo->prepare("
            INSERT INTO tournaments (id, name, description, start_date, end_date, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        foreach ($tournaments as $tournament) {
            $stmt->execute(array_values($tournament));
        }
        
        // Create test teams
        $teams = [
            ['id' => 1, 'name' => 'Test Team 1', 'description' => 'Test team description'],
            ['id' => 2, 'name' => 'Test Team 2', 'description' => 'Test team description 2']
        ];
        
        $stmt = self::$pdo->prepare("
            INSERT INTO teams (id, name, description)
            VALUES (?, ?, ?)
        ");
        
        foreach ($teams as $team) {
            $stmt->execute(array_values($team));
        }
    }
}

/**
 * Test Cache Helper
 */
class TestCacheHelper {
    private static $cache;
    
    public static function getInstance() {
        if (!self::$cache) {
            $pdo = TestDatabaseHelper::getInstance();
            self::$cache = new CacheManager($pdo, [
                'host' => getenv('REDIS_HOST') ?: '127.0.0.1',
                'port' => getenv('REDIS_PORT') ?: 6379,
                'database' => getenv('REDIS_DATABASE') ?: 1
            ]);
        }
        return self::$cache;
    }
    
    public static function clearTestCache() {
        self::getInstance()->clear();
    }
}

/**
 * Mock Helper for External Services
 */
class MockHelper {
    private static $mocks = [];
    
    public static function mockRedis() {
        if (!isset(self::$mocks['redis'])) {
            self::$mocks['redis'] = Mockery::mock('Redis');
        }
        return self::$mocks['redis'];
    }
    
    public static function mockHttpClient() {
        if (!isset(self::$mocks['http'])) {
            self::$mocks['http'] = Mockery::mock('HttpClient');
        }
        return self::$mocks['http'];
    }
    
    public static function tearDown() {
        Mockery::close();
        self::$mocks = [];
    }
}

/**
 * HTTP Test Helper
 */
class HttpTestHelper {
    public static function makeApiRequest($method, $path, $data = [], $headers = []) {
        $url = "http://localhost/api/v1$path";
        
        $context = [
            'http' => [
                'method' => $method,
                'header' => array_merge([
                    'Content-Type: application/json',
                    'Accept: application/json'
                ], $headers),
                'content' => !empty($data) ? json_encode($data) : null
            ]
        ];
        
        $response = file_get_contents($url, false, stream_context_create($context));
        $httpCode = http_response_code();
        
        return [
            'body' => json_decode($response, true),
            'status' => $httpCode,
            'raw' => $response
        ];
    }
    
    public static function authenticateUser($userId = 1) {
        // Generate test JWT token
        $payload = [
            'user_id' => $userId,
            'exp' => time() + 3600,
            'iat' => time()
        ];
        
        // Simple base64 encode for testing (use proper JWT in production)
        return base64_encode(json_encode($payload));
    }
}

/**
 * Assertion Helpers
 */
trait CustomAssertions {
    public function assertApiResponse($response, $expectedStatus = 200) {
        $this->assertIsArray($response);
        $this->assertEquals($expectedStatus, $response['status']);
        
        if ($expectedStatus >= 200 && $expectedStatus < 300) {
            $this->assertTrue($response['body']['success']);
            $this->assertArrayHasKey('data', $response['body']);
        } else {
            $this->assertFalse($response['body']['success']);
            $this->assertArrayHasKey('error', $response['body']);
        }
    }
    
    public function assertDatabaseHas($table, $conditions) {
        $pdo = TestDatabaseHelper::getInstance();
        
        $where = [];
        $values = [];
        foreach ($conditions as $column => $value) {
            $where[] = "$column = ?";
            $values[] = $value;
        }
        
        $sql = "SELECT COUNT(*) FROM $table WHERE " . implode(' AND ', $where);
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        
        $count = $stmt->fetchColumn();
        $this->assertGreaterThan(0, $count, "Failed asserting that table '$table' contains matching records");
    }
    
    public function assertDatabaseMissing($table, $conditions) {
        $pdo = TestDatabaseHelper::getInstance();
        
        $where = [];
        $values = [];
        foreach ($conditions as $column => $value) {
            $where[] = "$column = ?";
            $values[] = $value;
        }
        
        $sql = "SELECT COUNT(*) FROM $table WHERE " . implode(' AND ', $where);
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        
        $count = $stmt->fetchColumn();
        $this->assertEquals(0, $count, "Failed asserting that table '$table' does not contain matching records");
    }
}

// Initialize test environment
try {
    $testDb = TestDatabaseHelper::getInstance();
    echo "✓ Test database initialized\n";
} catch (Exception $e) {
    echo "✗ Failed to initialize test database: " . $e->getMessage() . "\n";
    exit(1);
}

// Set up global test state
register_shutdown_function(function() {
    MockHelper::tearDown();
});

echo "✓ Test environment ready\n";
?>
