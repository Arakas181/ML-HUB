<?php

use PHPUnit\Framework\TestCase;

class SecurityMiddlewareTest extends TestCase {
    use CustomAssertions;
    
    private $security;
    private $pdo;
    
    protected function setUp(): void {
        $this->pdo = TestDatabaseHelper::getInstance();
        $this->security = new SecurityMiddleware($this->pdo);
        
        // Clean up before each test
        TestDatabaseHelper::truncateAllTables();
    }
    
    protected function tearDown(): void {
        TestCacheHelper::clearTestCache();
    }
    
    public function testGenerateCSRFToken() {
        $token = $this->security->generateCSRFToken(1);
        
        $this->assertIsString($token);
        $this->assertEquals(64, strlen($token)); // 32 bytes = 64 hex chars
        
        // Verify token is stored in database
        $this->assertDatabaseHas('csrf_tokens', [
            'token' => $token,
            'user_id' => 1
        ]);
    }
    
    public function testValidateCSRFTokenWithValidToken() {
        $userId = 1;
        $token = $this->security->generateCSRFToken($userId);
        
        $isValid = $this->security->validateCSRFToken($token, $userId);
        
        $this->assertTrue($isValid);
        
        // Token should be removed after validation
        $this->assertDatabaseMissing('csrf_tokens', [
            'token' => $token
        ]);
    }
    
    public function testValidateCSRFTokenWithInvalidToken() {
        $isValid = $this->security->validateCSRFToken('invalid_token', 1);
        
        $this->assertFalse($isValid);
        
        // Should log security event
        $this->assertDatabaseHas('security_logs', [
            'event_type' => 'csrf_violation'
        ]);
    }
    
    public function testRateLimitingWithinLimit() {
        $_SERVER['REQUEST_URI'] = '/test/endpoint';
        
        // Should allow requests within limit
        for ($i = 0; $i < 10; $i++) {
            $allowed = $this->security->checkRateLimit('/test/endpoint', 20);
            $this->assertTrue($allowed);
        }
    }
    
    public function testRateLimitingExceedsLimit() {
        $_SERVER['REQUEST_URI'] = '/test/endpoint';
        
        // Fill up to limit
        for ($i = 0; $i < 5; $i++) {
            $this->security->checkRateLimit('/test/endpoint', 5);
        }
        
        // Next request should be blocked
        $allowed = $this->security->checkRateLimit('/test/endpoint', 5);
        $this->assertFalse($allowed);
        
        // Should log rate limit exceeded
        $this->assertDatabaseHas('security_logs', [
            'event_type' => 'rate_limit_exceeded'
        ]);
    }
    
    public function testInputSanitization() {
        $tests = [
            ['<script>alert("xss")</script>', '&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;', 'string'],
            ['user@example.com', 'user@example.com', 'email'],
            ['123', '123', 'int'],
            ['123.45', '123.45', 'float'],
            ['https://example.com', 'https://example.com', 'url']
        ];
        
        foreach ($tests as [$input, $expected, $type]) {
            $result = $this->security->sanitizeInput($input, $type);
            $this->assertEquals($expected, $result, "Failed sanitizing '$input' as '$type'");
        }
    }
    
    public function testInputValidationWithValidData() {
        $data = [
            'name' => 'John Doe',
            'email' => 'john@example.com',
            'age' => 25,
            'website' => 'https://johndoe.com'
        ];
        
        $rules = [
            'name' => ['required' => true, 'max_length' => 50],
            'email' => ['required' => true, 'type' => 'email'],
            'age' => ['type' => 'int'],
            'website' => ['type' => 'url']
        ];
        
        $errors = $this->security->validateInput($data, $rules);
        
        $this->assertEmpty($errors);
    }
    
    public function testInputValidationWithInvalidData() {
        $data = [
            'name' => '', // Required but empty
            'email' => 'invalid-email', // Invalid email format
            'age' => 'not-a-number', // Invalid integer
            'website' => 'not-a-url' // Invalid URL
        ];
        
        $rules = [
            'name' => ['required' => true, 'max_length' => 50],
            'email' => ['required' => true, 'type' => 'email'],
            'age' => ['type' => 'int'],
            'website' => ['type' => 'url']
        ];
        
        $errors = $this->security->validateInput($data, $rules);
        
        $this->assertNotEmpty($errors);
        $this->assertArrayHasKey('name', $errors);
        $this->assertArrayHasKey('email', $errors);
        $this->assertArrayHasKey('age', $errors);
        $this->assertArrayHasKey('website', $errors);
    }
    
    public function testInputValidationLengthConstraints() {
        $data = [
            'short_field' => 'ab', // Too short
            'long_field' => str_repeat('a', 101) // Too long
        ];
        
        $rules = [
            'short_field' => ['min_length' => 3],
            'long_field' => ['max_length' => 100]
        ];
        
        $errors = $this->security->validateInput($data, $rules);
        
        $this->assertArrayHasKey('short_field', $errors);
        $this->assertArrayHasKey('long_field', $errors);
    }
    
    public function testInputValidationPatternMatching() {
        $data = [
            'username' => 'invalid username!', // Contains invalid characters
            'phone' => '123-456-7890'
        ];
        
        $rules = [
            'username' => [
                'pattern' => '/^[a-zA-Z0-9_]+$/',
                'pattern_message' => 'Username can only contain letters, numbers and underscores'
            ],
            'phone' => [
                'pattern' => '/^\d{3}-\d{3}-\d{4}$/',
                'pattern_message' => 'Phone must be in format XXX-XXX-XXXX'
            ]
        ];
        
        $errors = $this->security->validateInput($data, $rules);
        
        $this->assertArrayHasKey('username', $errors);
        $this->assertEquals('Username can only contain letters, numbers and underscores', $errors['username']);
        
        $this->assertArrayNotHasKey('phone', $errors); // Valid phone format
    }
    
    public function testLogSecurityEvent() {
        $this->security->logSecurityEvent('failed_login', [
            'username' => 'test_user',
            'ip' => '192.168.1.1'
        ]);
        
        $this->assertDatabaseHas('security_logs', [
            'event_type' => 'failed_login'
        ]);
        
        // Verify details are stored as JSON
        $stmt = $this->pdo->prepare("
            SELECT details FROM security_logs 
            WHERE event_type = 'failed_login' 
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $log = $stmt->fetch();
        
        $details = json_decode($log['details'], true);
        $this->assertEquals('test_user', $details['username']);
        $this->assertEquals('192.168.1.1', $details['ip']);
    }
    
    public function testCleanupExpiredTokens() {
        // Create an expired token manually
        $stmt = $this->pdo->prepare("
            INSERT INTO csrf_tokens (token, user_id, expires_at)
            VALUES (?, ?, ?)
        ");
        
        $expiredToken = 'expired_token_123';
        $expiredTime = date('Y-m-d H:i:s', time() - 3600); // 1 hour ago
        
        $stmt->execute([$expiredToken, 1, $expiredTime]);
        
        // Verify token exists
        $this->assertDatabaseHas('csrf_tokens', ['token' => $expiredToken]);
        
        // Run cleanup
        $this->security->cleanup();
        
        // Token should be removed
        $this->assertDatabaseMissing('csrf_tokens', ['token' => $expiredToken]);
    }
    
    public function testSecurityHeadersAreSet() {
        ob_start();
        $this->security->addSecurityHeaders();
        ob_end_clean();
        
        $headers = xdebug_get_headers();
        
        $expectedHeaders = [
            'Content-Security-Policy',
            'X-Content-Type-Options',
            'X-Frame-Options',
            'X-XSS-Protection',
            'Referrer-Policy'
        ];
        
        foreach ($expectedHeaders as $expectedHeader) {
            $found = false;
            foreach ($headers as $header) {
                if (strpos($header, $expectedHeader) === 0) {
                    $found = true;
                    break;
                }
            }
            $this->assertTrue($found, "Security header '$expectedHeader' was not set");
        }
    }
    
    /**
     * Test that rate limiting works correctly across different IPs
     */
    public function testRateLimitingPerIP() {
        // Mock different IP addresses
        $originalRemoteAddr = $_SERVER['REMOTE_ADDR'] ?? null;
        
        try {
            // Test with first IP
            $_SERVER['REMOTE_ADDR'] = '192.168.1.1';
            for ($i = 0; $i < 5; $i++) {
                $allowed = $this->security->checkRateLimit('/test', 5);
                $this->assertTrue($allowed);
            }
            $blocked = $this->security->checkRateLimit('/test', 5);
            $this->assertFalse($blocked);
            
            // Test with second IP - should not be affected by first IP's limit
            $_SERVER['REMOTE_ADDR'] = '192.168.1.2';
            $allowed = $this->security->checkRateLimit('/test', 5);
            $this->assertTrue($allowed);
            
        } finally {
            if ($originalRemoteAddr !== null) {
                $_SERVER['REMOTE_ADDR'] = $originalRemoteAddr;
            } else {
                unset($_SERVER['REMOTE_ADDR']);
            }
        }
    }
    
    /**
     * Test CSRF token expiration
     */
    public function testCSRFTokenExpiration() {
        // Create a token that will expire quickly
        $userId = 1;
        $token = $this->security->generateCSRFToken($userId);
        
        // Manually update the token to be expired
        $stmt = $this->pdo->prepare("
            UPDATE csrf_tokens 
            SET expires_at = ? 
            WHERE token = ?
        ");
        $expiredTime = date('Y-m-d H:i:s', time() - 1); // 1 second ago
        $stmt->execute([$expiredTime, $token]);
        
        // Token should now be invalid
        $isValid = $this->security->validateCSRFToken($token, $userId);
        $this->assertFalse($isValid);
    }
}
