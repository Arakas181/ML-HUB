/**
 * Enhanced WebSocket Server for Esports Platform
 * Built with Node.js and Socket.io for scalable real-time communication
 */

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const redis = require('redis');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const cors = require('cors');

const app = express();
const server = http.createServer(app);

// Initialize Socket.io with CORS configuration
const io = socketIo(server, {
  cors: {
    origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ["http://localhost", "http://localhost:3000", "http://localhost:8080"],
    methods: ["GET", "POST"],
    credentials: true
  },
  transports: ['websocket', 'polling']
});

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ["http://localhost", "http://localhost:3000", "http://localhost:8080"],
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

app.use(express.json({ limit: '10mb' }));

// Redis client setup
let redisClient;
const connectRedis = async () => {
  try {
    redisClient = redis.createClient({
      host: process.env.REDIS_HOST || 'localhost',
      port: process.env.REDIS_PORT || 6379,
      password: process.env.REDIS_PASSWORD,
      db: process.env.REDIS_DB || 0
    });
    
    await redisClient.connect();
    console.log('✅ Connected to Redis');
  } catch (error) {
    console.error('❌ Redis connection failed:', error.message);
    process.exit(1);
  }
};

// MySQL connection pool
let mysqlPool;
const connectDatabase = async () => {
  try {
    mysqlPool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASS || '',
      database: process.env.DB_NAME || 'esports_platform',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    
    // Test connection
    const connection = await mysqlPool.getConnection();
    await connection.ping();
    connection.release();
    console.log('✅ Connected to MySQL');
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    process.exit(1);
  }
};

// User authentication middleware for Socket.io
const authenticateSocket = async (socket, next) => {
  try {
    const token = socket.handshake.auth.token || socket.handshake.headers.authorization;
    
    if (!token) {
      return next(new Error('Authentication token required'));
    }
    
    // Verify JWT token (simplified - use proper JWT library in production)
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    
    // Fetch user from database
    const [rows] = await mysqlPool.execute(
      'SELECT id, username, role, last_active FROM users WHERE id = ?',
      [decoded.user_id]
    );
    
    if (rows.length === 0) {
      return next(new Error('User not found'));
    }
    
    socket.userId = rows[0].id;
    socket.username = rows[0].username;
    socket.userRole = rows[0].role;
    
    next();
  } catch (error) {
    next(new Error('Authentication failed'));
  }
};

// Store active connections
const activeConnections = new Map();
const roomUsers = new Map();

// Socket.io connection handling
io.use(authenticateSocket);

io.on('connection', (socket) => {
  console.log(`👤 User connected: ${socket.username} (${socket.userId})`);
  
  // Store active connection
  activeConnections.set(socket.userId, {
    socketId: socket.id,
    username: socket.username,
    role: socket.userRole,
    connectedAt: new Date(),
    rooms: []
  });
  
  // Update user's last active time
  updateUserActivity(socket.userId);
  
  // Handle room joining
  socket.on('join_room', async (data) => {
    try {
      const { roomId, roomType = 'general' } = data;
      const roomKey = `room:${roomId}`;
      
      // Leave previous rooms if joining a new one
      if (socket.currentRoom && socket.currentRoom !== roomKey) {
        socket.leave(socket.currentRoom);
        await leaveRoom(socket, socket.currentRoom);
      }
      
      // Join new room
      socket.join(roomKey);
      socket.currentRoom = roomKey;
      
      // Add user to room tracking
      if (!roomUsers.has(roomKey)) {
        roomUsers.set(roomKey, new Map());
      }
      
      roomUsers.get(roomKey).set(socket.userId, {
        socketId: socket.id,
        username: socket.username,
        role: socket.userRole,
        joinedAt: new Date()
      });
      
      // Update active connection info
      const userConnection = activeConnections.get(socket.userId);
      if (userConnection) {
        userConnection.rooms.push(roomKey);
      }
      
      // Notify other users in room
      socket.to(roomKey).emit('user_joined', {
        userId: socket.userId,
        username: socket.username,
        role: socket.userRole
      });
      
      // Send current room users to newly joined user
      const roomUsersList = Array.from(roomUsers.get(roomKey).values());
      socket.emit('room_users', roomUsersList);
      
      // Load recent messages for the room
      const recentMessages = await getRecentMessages(roomId, 50);
      socket.emit('recent_messages', recentMessages);
      
      console.log(`🏠 ${socket.username} joined room: ${roomKey}`);
      
    } catch (error) {
      console.error('Error joining room:', error);
      socket.emit('error', { message: 'Failed to join room' });
    }
  });
  
  // Handle chat messages
  socket.on('send_message', async (data) => {
    try {
      const { roomId, message, messageType = 'text' } = data;
      const roomKey = `room:${roomId}`;
      
      // Validate message
      if (!message || message.trim().length === 0) {
        return socket.emit('error', { message: 'Message cannot be empty' });
      }
      
      if (message.length > 500) {
        return socket.emit('error', { message: 'Message too long' });
      }
      
      // Rate limiting per user
      const rateLimitKey = `rate_limit:${socket.userId}`;
      const currentCount = await redisClient.get(rateLimitKey) || 0;
      
      if (currentCount >= 10) { // 10 messages per minute
        return socket.emit('error', { message: 'Rate limit exceeded' });
      }
      
      await redisClient.setEx(rateLimitKey, 60, parseInt(currentCount) + 1);
      
      // Create message object
      const messageObj = {
        id: generateMessageId(),
        roomId: parseInt(roomId),
        userId: socket.userId,
        username: socket.username,
        userRole: socket.userRole,
        message: message.trim(),
        messageType,
        timestamp: new Date(),
        edited: false
      };
      
      // Save to database
      await saveMessage(messageObj);
      
      // Broadcast to room
      io.to(roomKey).emit('new_message', messageObj);
      
      console.log(`💬 Message from ${socket.username} in ${roomKey}: ${message.substring(0, 50)}...`);
      
    } catch (error) {
      console.error('Error sending message:', error);
      socket.emit('error', { message: 'Failed to send message' });
    }
  });
  
  // Handle typing indicators
  socket.on('typing', (data) => {
    const { roomId } = data;
    const roomKey = `room:${roomId}`;
    
    socket.to(roomKey).emit('user_typing', {
      userId: socket.userId,
      username: socket.username
    });
  });
  
  socket.on('stop_typing', (data) => {
    const { roomId } = data;
    const roomKey = `room:${roomId}`;
    
    socket.to(roomKey).emit('user_stopped_typing', {
      userId: socket.userId,
      username: socket.username
    });
  });
  
  // Handle live match updates
  socket.on('subscribe_match', (data) => {
    const { matchId } = data;
    const matchRoom = `match:${matchId}`;
    socket.join(matchRoom);
    console.log(`🎮 ${socket.username} subscribed to match ${matchId}`);
  });
  
  socket.on('unsubscribe_match', (data) => {
    const { matchId } = data;
    const matchRoom = `match:${matchId}`;
    socket.leave(matchRoom);
    console.log(`🎮 ${socket.username} unsubscribed from match ${matchId}`);
  });
  
  // Handle tournament updates
  socket.on('subscribe_tournament', (data) => {
    const { tournamentId } = data;
    const tournamentRoom = `tournament:${tournamentId}`;
    socket.join(tournamentRoom);
    console.log(`🏆 ${socket.username} subscribed to tournament ${tournamentId}`);
  });
  
  // Handle live polls
  socket.on('vote_poll', async (data) => {
    try {
      const { pollId, optionIndex } = data;
      
      // Validate vote
      const voteResult = await submitPollVote(socket.userId, pollId, optionIndex);
      
      if (voteResult.success) {
        // Broadcast updated poll results
        const pollResults = await getPollResults(pollId);
        io.emit('poll_updated', { pollId, results: pollResults });
      } else {
        socket.emit('error', { message: voteResult.error });
      }
      
    } catch (error) {
      console.error('Error voting on poll:', error);
      socket.emit('error', { message: 'Failed to submit vote' });
    }
  });
  
  // Handle disconnection
  socket.on('disconnect', async () => {
    console.log(`👋 User disconnected: ${socket.username} (${socket.userId})`);
    
    // Remove from active connections
    activeConnections.delete(socket.userId);
    
    // Remove from room tracking and notify other users
    if (socket.currentRoom && roomUsers.has(socket.currentRoom)) {
      roomUsers.get(socket.currentRoom).delete(socket.userId);
      
      socket.to(socket.currentRoom).emit('user_left', {
        userId: socket.userId,
        username: socket.username
      });
      
      // Clean up empty rooms
      if (roomUsers.get(socket.currentRoom).size === 0) {
        roomUsers.delete(socket.currentRoom);
      }
    }
    
    // Update user's last active time
    await updateUserActivity(socket.userId);
  });
  
  // Handle errors
  socket.on('error', (error) => {
    console.error(`Socket error for ${socket.username}:`, error);
  });
});

// Helper functions
async function updateUserActivity(userId) {
  try {
    await mysqlPool.execute(
      'UPDATE users SET last_active = NOW() WHERE id = ?',
      [userId]
    );
  } catch (error) {
    console.error('Error updating user activity:', error);
  }
}

async function saveMessage(messageObj) {
  try {
    await mysqlPool.execute(
      `INSERT INTO enhanced_chat_messages 
       (chat_room_id, user_id, username, user_role, message, message_type, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        messageObj.roomId,
        messageObj.userId,
        messageObj.username,
        messageObj.userRole,
        messageObj.message,
        messageObj.messageType,
        messageObj.timestamp
      ]
    );
  } catch (error) {
    console.error('Error saving message:', error);
  }
}

async function getRecentMessages(roomId, limit = 50) {
  try {
    const [rows] = await mysqlPool.execute(
      `SELECT * FROM enhanced_chat_messages 
       WHERE chat_room_id = ? AND is_deleted = FALSE
       ORDER BY created_at DESC 
       LIMIT ?`,
      [roomId, limit]
    );
    
    return rows.reverse(); // Return in chronological order
  } catch (error) {
    console.error('Error fetching recent messages:', error);
    return [];
  }
}

async function submitPollVote(userId, pollId, optionIndex) {
  try {
    // Check if poll exists and is active
    const [pollRows] = await mysqlPool.execute(
      'SELECT * FROM live_polls WHERE id = ? AND status = "active"',
      [pollId]
    );
    
    if (pollRows.length === 0) {
      return { success: false, error: 'Poll not found or not active' };
    }
    
    // Check if user has already voted
    const [voteRows] = await mysqlPool.execute(
      'SELECT * FROM poll_votes WHERE poll_id = ? AND user_id = ?',
      [pollId, userId]
    );
    
    if (voteRows.length > 0) {
      return { success: false, error: 'You have already voted on this poll' };
    }
    
    // Submit vote
    await mysqlPool.execute(
      'INSERT INTO poll_votes (poll_id, user_id, option_index) VALUES (?, ?, ?)',
      [pollId, userId, optionIndex]
    );
    
    return { success: true };
  } catch (error) {
    console.error('Error submitting poll vote:', error);
    return { success: false, error: 'Failed to submit vote' };
  }
}

async function getPollResults(pollId) {
  try {
    const [rows] = await mysqlPool.execute(
      `SELECT option_index, COUNT(*) as vote_count
       FROM poll_votes 
       WHERE poll_id = ?
       GROUP BY option_index`,
      [pollId]
    );
    
    return rows;
  } catch (error) {
    console.error('Error getting poll results:', error);
    return [];
  }
}

async function leaveRoom(socket, roomKey) {
  if (roomUsers.has(roomKey)) {
    roomUsers.get(roomKey).delete(socket.userId);
    
    socket.to(roomKey).emit('user_left', {
      userId: socket.userId,
      username: socket.username
    });
  }
}

function generateMessageId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// API endpoints for external integrations
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date(),
    activeConnections: activeConnections.size,
    activeRooms: roomUsers.size
  });
});

app.get('/stats', (req, res) => {
  const stats = {
    activeConnections: activeConnections.size,
    activeRooms: roomUsers.size,
    memoryUsage: process.memoryUsage(),
    uptime: process.uptime()
  };
  
  res.json(stats);
});

// Broadcast match updates (called by external services)
app.post('/api/match/update', async (req, res) => {
  try {
    const { matchId, update } = req.body;
    
    // Validate match exists
    const [matchRows] = await mysqlPool.execute(
      'SELECT * FROM matches WHERE id = ?',
      [matchId]
    );
    
    if (matchRows.length === 0) {
      return res.status(404).json({ error: 'Match not found' });
    }
    
    // Broadcast to subscribers
    io.to(`match:${matchId}`).emit('match_update', {
      matchId,
      update,
      timestamp: new Date()
    });
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error broadcasting match update:', error);
    res.status(500).json({ error: 'Failed to broadcast update' });
  }
});

// Initialize connections and start server
async function startServer() {
  try {
    await connectRedis();
    await connectDatabase();
    
    const PORT = process.env.PORT || 3001;
    server.listen(PORT, () => {
      console.log(`🚀 Enhanced WebSocket server running on port ${PORT}`);
      console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
    });
    
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('🛑 Shutting down gracefully...');
  
  // Close all connections
  io.close(() => {
    console.log('✅ Socket.io connections closed');
  });
  
  // Close database pool
  if (mysqlPool) {
    await mysqlPool.end();
    console.log('✅ Database pool closed');
  }
  
  // Close Redis connection
  if (redisClient) {
    await redisClient.quit();
    console.log('✅ Redis connection closed');
  }
  
  process.exit(0);
});

// Start the server
startServer();
