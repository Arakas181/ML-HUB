<?php
/**
 * Cache Manager for Esports Platform
 * Handles Redis caching, session management, and performance optimization
 */

class CacheManager {
    private $redis;
    private $pdo;
    private $isRedisAvailable = false;
    private $defaultTTL = 3600; // 1 hour
    
    public function __construct($pdo, $redisConfig = []) {
        $this->pdo = $pdo;
        $this->initializeRedis($redisConfig);
    }
    
    /**
     * Initialize Redis connection
     */
    private function initializeRedis($config = []) {
        if (!extension_loaded('redis')) {
            error_log('Redis extension not available, falling back to database caching');
            return;
        }
        
        try {
            $this->redis = new Redis();
            $host = $config['host'] ?? '127.0.0.1';
            $port = $config['port'] ?? 6379;
            $timeout = $config['timeout'] ?? 2.5;
            
            $connected = $this->redis->connect($host, $port, $timeout);
            
            if ($connected && isset($config['password'])) {
                $this->redis->auth($config['password']);
            }
            
            if ($connected && isset($config['database'])) {
                $this->redis->select($config['database']);
            }
            
            // Test connection
            $this->redis->ping();
            $this->isRedisAvailable = true;
            
            // Set Redis options for better performance
            $this->redis->setOption(Redis::OPT_SERIALIZER, Redis::SERIALIZER_JSON);
            $this->redis->setOption(Redis::OPT_PREFIX, 'esports:');
            
        } catch (Exception $e) {
            error_log("Redis connection failed: " . $e->getMessage());
            $this->isRedisAvailable = false;
        }
    }
    
    /**
     * Get cached data
     */
    public function get($key) {
        if ($this->isRedisAvailable) {
            return $this->redis->get($key);
        }
        
        // Fallback to database cache
        return $this->getDatabaseCache($key);
    }
    
    /**
     * Set cache data
     */
    public function set($key, $value, $ttl = null) {
        $ttl = $ttl ?? $this->defaultTTL;
        
        if ($this->isRedisAvailable) {
            return $this->redis->setex($key, $ttl, $value);
        }
        
        // Fallback to database cache
        return $this->setDatabaseCache($key, $value, $ttl);
    }
    
    /**
     * Delete cache key
     */
    public function delete($key) {
        if ($this->isRedisAvailable) {
            return $this->redis->del($key);
        }
        
        return $this->deleteDatabaseCache($key);
    }
    
    /**
     * Check if key exists
     */
    public function exists($key) {
        if ($this->isRedisAvailable) {
            return $this->redis->exists($key);
        }
        
        return $this->existsDatabaseCache($key);
    }
    
    /**
     * Increment counter
     */
    public function increment($key, $value = 1) {
        if ($this->isRedisAvailable) {
            return $this->redis->incrBy($key, $value);
        }
        
        // Fallback implementation
        $current = $this->get($key) ?? 0;
        $new = $current + $value;
        $this->set($key, $new);
        return $new;
    }
    
    /**
     * Cache database query results
     */
    public function cacheQuery($key, $query, $params = [], $ttl = null) {
        $cached = $this->get($key);
        
        if ($cached !== false) {
            return json_decode($cached, true);
        }
        
        // Execute query
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Cache results
        $this->set($key, json_encode($results), $ttl);
        
        return $results;
    }
    
    /**
     * Cache tournaments with automatic invalidation
     */
    public function getTournaments($filters = []) {
        $cacheKey = 'tournaments:' . md5(serialize($filters));
        
        $tournaments = $this->get($cacheKey);
        if ($tournaments !== false) {
            return json_decode($tournaments, true);
        }
        
        // Build query based on filters
        $where = ['1=1'];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = 'status = ?';
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['upcoming'])) {
            $where[] = 'start_date >= CURDATE()';
        }
        
        $query = "
            SELECT t.*, u.username as creator_name,
                   (SELECT COUNT(*) FROM tournament_participants tp WHERE tp.tournament_id = t.id) as participant_count
            FROM tournaments t 
            LEFT JOIN users u ON t.created_by = u.id 
            WHERE " . implode(' AND ', $where) . "
            ORDER BY t.start_date ASC
            LIMIT 50
        ";
        
        $tournaments = $this->cacheQuery($cacheKey, $query, $params, 900); // 15 minutes
        
        // Set cache tags for invalidation
        $this->setTags($cacheKey, ['tournaments']);
        
        return $tournaments;
    }
    
    /**
     * Cache user data
     */
    public function getUser($userId) {
        $cacheKey = "user:$userId";
        
        $user = $this->get($cacheKey);
        if ($user !== false) {
            return json_decode($user, true);
        }
        
        $query = "
            SELECT id, username, email, full_name, role, avatar_url, 
                   last_active, created_at
            FROM users 
            WHERE id = ?
        ";
        
        $stmt = $this->pdo->prepare($query);
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $this->set($cacheKey, json_encode($user), 1800); // 30 minutes
            $this->setTags($cacheKey, ['users', "user:$userId"]);
        }
        
        return $user;
    }
    
    /**
     * Session management with Redis
     */
    public function setSession($sessionId, $data, $ttl = 86400) {
        $key = "session:$sessionId";
        return $this->set($key, json_encode($data), $ttl);
    }
    
    public function getSession($sessionId) {
        $key = "session:$sessionId";
        $data = $this->get($key);
        return $data ? json_decode($data, true) : null;
    }
    
    public function destroySession($sessionId) {
        $key = "session:$sessionId";
        return $this->delete($key);
    }
    
    /**
     * Cache leaderboards and statistics
     */
    public function getLeaderboard($type = 'tournament_wins', $limit = 10) {
        $cacheKey = "leaderboard:$type:$limit";
        
        $leaderboard = $this->get($cacheKey);
        if ($leaderboard !== false) {
            return json_decode($leaderboard, true);
        }
        
        $query = match($type) {
            'tournament_wins' => "
                SELECT u.id, u.username, u.avatar_url,
                       COUNT(tp.id) as wins
                FROM users u
                JOIN tournament_participants tp ON u.id = tp.user_id
                WHERE tp.status = 'winner'
                GROUP BY u.id, u.username, u.avatar_url
                ORDER BY wins DESC
                LIMIT ?
            ",
            'matches_played' => "
                SELECT u.id, u.username, u.avatar_url,
                       COUNT(tp.id) as matches
                FROM users u
                JOIN tournament_participants tp ON u.id = tp.user_id
                JOIN tournaments t ON tp.tournament_id = t.id
                WHERE t.status = 'completed'
                GROUP BY u.id, u.username, u.avatar_url
                ORDER BY matches DESC
                LIMIT ?
            ",
            default => "SELECT 1 LIMIT 0"
        };
        
        $leaderboard = $this->cacheQuery($cacheKey, $query, [$limit], 1800); // 30 minutes
        $this->setTags($cacheKey, ['leaderboards', 'users']);
        
        return $leaderboard;
    }
    
    /**
     * Cache tags for selective invalidation
     */
    private function setTags($key, $tags) {
        if (!$this->isRedisAvailable) return;
        
        foreach ($tags as $tag) {
            $this->redis->sAdd("tag:$tag", $key);
            $this->redis->expire("tag:$tag", 7200); // 2 hours
        }
    }
    
    /**
     * Invalidate cache by tags
     */
    public function invalidateTag($tag) {
        if (!$this->isRedisAvailable) {
            $this->invalidateDatabaseCacheByTag($tag);
            return;
        }
        
        $keys = $this->redis->sMembers("tag:$tag");
        if (!empty($keys)) {
            $this->redis->del($keys);
            $this->redis->del("tag:$tag");
        }
    }
    
    /**
     * Clear all cache
     */
    public function clear() {
        if ($this->isRedisAvailable) {
            return $this->redis->flushDB();
        }
        
        // Clear database cache
        $this->pdo->exec("DELETE FROM cache_data WHERE expires_at < NOW()");
        return true;
    }
    
    /**
     * Get cache statistics
     */
    public function getStats() {
        if ($this->isRedisAvailable) {
            $info = $this->redis->info();
            return [
                'type' => 'redis',
                'memory_used' => $info['used_memory_human'] ?? 'unknown',
                'connected_clients' => $info['connected_clients'] ?? 0,
                'total_commands' => $info['total_commands_processed'] ?? 0,
                'keyspace_hits' => $info['keyspace_hits'] ?? 0,
                'keyspace_misses' => $info['keyspace_misses'] ?? 0,
                'hit_rate' => $this->calculateHitRate($info)
            ];
        }
        
        return [
            'type' => 'database',
            'total_keys' => $this->getDatabaseCacheCount(),
            'expired_keys' => $this->getExpiredCacheCount()
        ];
    }
    
    /**
     * Performance monitoring
     */
    public function recordQueryTime($query, $time) {
        if ($time > 1.0) { // Log slow queries (>1 second)
            error_log("Slow query detected: {$time}s - " . substr($query, 0, 100));
            
            // Increment slow query counter
            $this->increment('stats:slow_queries', 1);
        }
        
        // Record in performance metrics
        $key = 'performance:queries:' . date('Y-m-d-H');
        $this->increment($key, 1);
        $this->redis->expire($key, 7200); // Keep for 2 hours
    }
    
    // Database cache fallback methods
    private function initDatabaseCache() {
        $sql = "
            CREATE TABLE IF NOT EXISTS cache_data (
                cache_key VARCHAR(255) PRIMARY KEY,
                cache_value LONGTEXT NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_expires (expires_at)
            )
        ";
        $this->pdo->exec($sql);
    }
    
    private function getDatabaseCache($key) {
        $this->initDatabaseCache();
        
        $stmt = $this->pdo->prepare("
            SELECT cache_value FROM cache_data 
            WHERE cache_key = ? AND expires_at > NOW()
        ");
        $stmt->execute([$key]);
        
        $result = $stmt->fetch();
        return $result ? $result['cache_value'] : false;
    }
    
    private function setDatabaseCache($key, $value, $ttl) {
        $this->initDatabaseCache();
        
        $expiresAt = date('Y-m-d H:i:s', time() + $ttl);
        
        $stmt = $this->pdo->prepare("
            REPLACE INTO cache_data (cache_key, cache_value, expires_at)
            VALUES (?, ?, ?)
        ");
        
        return $stmt->execute([$key, $value, $expiresAt]);
    }
    
    private function deleteDatabaseCache($key) {
        $stmt = $this->pdo->prepare("DELETE FROM cache_data WHERE cache_key = ?");
        return $stmt->execute([$key]);
    }
    
    private function existsDatabaseCache($key) {
        $stmt = $this->pdo->prepare("
            SELECT 1 FROM cache_data 
            WHERE cache_key = ? AND expires_at > NOW()
        ");
        $stmt->execute([$key]);
        return (bool) $stmt->fetch();
    }
    
    private function calculateHitRate($info) {
        $hits = $info['keyspace_hits'] ?? 0;
        $misses = $info['keyspace_misses'] ?? 0;
        $total = $hits + $misses;
        
        return $total > 0 ? round(($hits / $total) * 100, 2) : 0;
    }
    
    private function getDatabaseCacheCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM cache_data");
        return $stmt->fetchColumn();
    }
    
    private function getExpiredCacheCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) FROM cache_data WHERE expires_at <= NOW()");
        return $stmt->fetchColumn();
    }
    
    private function invalidateDatabaseCacheByTag($tag) {
        // Simple implementation - in practice, you'd need a more sophisticated tagging system
        $this->pdo->prepare("DELETE FROM cache_data WHERE cache_key LIKE ?")->execute(["%$tag%"]);
    }
    
    /**
     * Cleanup expired cache entries
     */
    public function cleanup() {
        if (!$this->isRedisAvailable) {
            $this->pdo->exec("DELETE FROM cache_data WHERE expires_at <= NOW()");
        }
        // Redis handles TTL automatically
    }
}
?>
