<?php
/**
 * Security Middleware for Esports Platform
 * Handles CSRF protection, rate limiting, input validation, and security headers
 */

class SecurityMiddleware {
    private $pdo;
    private $rateLimitWindow = 900; // 15 minutes
    private $maxRequests = 100; // per window
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->initSecurityTables();
    }
    
    /**
     * Initialize security-related database tables
     */
    private function initSecurityTables() {
        $sql = "
            CREATE TABLE IF NOT EXISTS rate_limits (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ip_address VARCHAR(45) NOT NULL,
                endpoint VARCHAR(255) NOT NULL,
                request_count INT DEFAULT 1,
                window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_ip_endpoint (ip_address, endpoint),
                INDEX idx_window_start (window_start)
            );
            
            CREATE TABLE IF NOT EXISTS csrf_tokens (
                id INT AUTO_INCREMENT PRIMARY KEY,
                token VARCHAR(64) NOT NULL UNIQUE,
                user_id INT,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_token (token),
                INDEX idx_expires (expires_at)
            );
            
            CREATE TABLE IF NOT EXISTS security_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_type ENUM('csrf_violation', 'rate_limit_exceeded', 'suspicious_activity', 'failed_login') NOT NULL,
                ip_address VARCHAR(45),
                user_id INT NULL,
                details JSON,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_event_type (event_type),
                INDEX idx_ip_address (ip_address),
                INDEX idx_created_at (created_at)
            );
        ";
        
        $this->pdo->exec($sql);
    }
    
    /**
     * Add security headers to response
     */
    public function addSecurityHeaders() {
        // Content Security Policy
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; img-src 'self' data: https:; font-src 'self' https://cdn.jsdelivr.net; connect-src 'self' ws: wss:;");
        
        // Other security headers
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: DENY");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");
        header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
        
        // HSTS for HTTPS
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
        }
    }
    
    /**
     * Generate CSRF token
     */
    public function generateCSRFToken($userId = null) {
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 hour
        
        $stmt = $this->pdo->prepare("
            INSERT INTO csrf_tokens (token, user_id, expires_at) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$token, $userId, $expiresAt]);
        
        return $token;
    }
    
    /**
     * Validate CSRF token
     */
    public function validateCSRFToken($token, $userId = null) {
        $stmt = $this->pdo->prepare("
            SELECT id FROM csrf_tokens 
            WHERE token = ? AND expires_at > NOW() AND (user_id = ? OR user_id IS NULL)
        ");
        $stmt->execute([$token, $userId]);
        
        if ($stmt->fetch()) {
            // Remove used token
            $deleteStmt = $this->pdo->prepare("DELETE FROM csrf_tokens WHERE token = ?");
            $deleteStmt->execute([$token]);
            return true;
        }
        
        $this->logSecurityEvent('csrf_violation', [
            'token' => substr($token, 0, 8) . '...', // Log partial token for debugging
            'user_id' => $userId
        ]);
        
        return false;
    }
    
    /**
     * Rate limiting check
     */
    public function checkRateLimit($endpoint = null, $customLimit = null) {
        $ipAddress = $this->getClientIP();
        $endpoint = $endpoint ?: $_SERVER['REQUEST_URI'];
        $limit = $customLimit ?: $this->maxRequests;
        
        // Clean old entries
        $this->pdo->prepare("
            DELETE FROM rate_limits 
            WHERE window_start < DATE_SUB(NOW(), INTERVAL ? SECOND)
        ")->execute([$this->rateLimitWindow]);
        
        // Check current rate
        $stmt = $this->pdo->prepare("
            SELECT request_count FROM rate_limits 
            WHERE ip_address = ? AND endpoint = ? AND window_start > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        $stmt->execute([$ipAddress, $endpoint, $this->rateLimitWindow]);
        
        $result = $stmt->fetch();
        
        if ($result) {
            if ($result['request_count'] >= $limit) {
                $this->logSecurityEvent('rate_limit_exceeded', [
                    'endpoint' => $endpoint,
                    'request_count' => $result['request_count'],
                    'limit' => $limit
                ]);
                return false;
            }
            
            // Update count
            $this->pdo->prepare("
                UPDATE rate_limits 
                SET request_count = request_count + 1 
                WHERE ip_address = ? AND endpoint = ?
            ")->execute([$ipAddress, $endpoint]);
        } else {
            // Create new entry
            $this->pdo->prepare("
                INSERT INTO rate_limits (ip_address, endpoint, request_count) 
                VALUES (?, ?, 1)
            ")->execute([$ipAddress, $endpoint]);
        }
        
        return true;
    }
    
    /**
     * Input validation and sanitization
     */
    public function sanitizeInput($input, $type = 'string') {
        switch ($type) {
            case 'email':
                return filter_var($input, FILTER_SANITIZE_EMAIL);
            case 'int':
                return filter_var($input, FILTER_SANITIZE_NUMBER_INT);
            case 'float':
                return filter_var($input, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            case 'url':
                return filter_var($input, FILTER_SANITIZE_URL);
            case 'string':
            default:
                return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
        }
    }
    
    /**
     * Validate input based on rules
     */
    public function validateInput($data, $rules) {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            
            // Required check
            if (isset($rule['required']) && $rule['required'] && empty($value)) {
                $errors[$field] = "Field {$field} is required";
                continue;
            }
            
            if (empty($value)) continue;
            
            // Type validation
            switch ($rule['type'] ?? 'string') {
                case 'email':
                    if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[$field] = "Invalid email format";
                    }
                    break;
                case 'int':
                    if (!filter_var($value, FILTER_VALIDATE_INT)) {
                        $errors[$field] = "Invalid integer value";
                    }
                    break;
                case 'float':
                    if (!filter_var($value, FILTER_VALIDATE_FLOAT)) {
                        $errors[$field] = "Invalid numeric value";
                    }
                    break;
                case 'url':
                    if (!filter_var($value, FILTER_VALIDATE_URL)) {
                        $errors[$field] = "Invalid URL format";
                    }
                    break;
            }
            
            // Length validation
            if (isset($rule['min_length']) && strlen($value) < $rule['min_length']) {
                $errors[$field] = "Minimum length is {$rule['min_length']} characters";
            }
            
            if (isset($rule['max_length']) && strlen($value) > $rule['max_length']) {
                $errors[$field] = "Maximum length is {$rule['max_length']} characters";
            }
            
            // Pattern validation
            if (isset($rule['pattern']) && !preg_match($rule['pattern'], $value)) {
                $errors[$field] = $rule['pattern_message'] ?? "Invalid format";
            }
        }
        
        return $errors;
    }
    
    /**
     * Get client IP address
     */
    private function getClientIP() {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Log security events
     */
    public function logSecurityEvent($eventType, $details = []) {
        $stmt = $this->pdo->prepare("
            INSERT INTO security_logs (event_type, ip_address, user_id, details) 
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $eventType,
            $this->getClientIP(),
            $_SESSION['user_id'] ?? null,
            json_encode($details)
        ]);
    }
    
    /**
     * Clean expired tokens and old logs
     */
    public function cleanup() {
        // Remove expired CSRF tokens
        $this->pdo->exec("DELETE FROM csrf_tokens WHERE expires_at < NOW()");
        
        // Remove old rate limit entries
        $this->pdo->prepare("
            DELETE FROM rate_limits 
            WHERE window_start < DATE_SUB(NOW(), INTERVAL ? SECOND)
        ")->execute([$this->rateLimitWindow]);
        
        // Remove old security logs (keep for 30 days)
        $this->pdo->exec("
            DELETE FROM security_logs 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
    }
}
?>
