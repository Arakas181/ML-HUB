<?php
/**
 * Comprehensive Monitoring and Analytics System for Esports Platform
 * Handles application monitoring, error tracking, user analytics, and performance metrics
 */

class MonitoringSystem {
    private $pdo;
    private $redis;
    private $sentryDsn;
    private $isProduction;
    
    public function __construct($pdo, $redis = null, $config = []) {
        $this->pdo = $pdo;
        $this->redis = $redis;
        $this->sentryDsn = $config['sentry_dsn'] ?? null;
        $this->isProduction = ($config['environment'] ?? 'development') === 'production';
        
        $this->initializeMonitoringTables();
        $this->initializeSentry();
    }
    
    /**
     * Initialize monitoring database tables
     */
    private function initializeMonitoringTables() {
        $sql = "
            -- Application metrics table
            CREATE TABLE IF NOT EXISTS app_metrics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                metric_name VARCHAR(255) NOT NULL,
                metric_value DECIMAL(15,4) NOT NULL,
                metric_type ENUM('counter', 'gauge', 'histogram', 'timer') NOT NULL,
                tags JSON,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_metric_name (metric_name),
                INDEX idx_timestamp (timestamp)
            );
            
            -- Error logs table
            CREATE TABLE IF NOT EXISTS error_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                error_level ENUM('debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency') NOT NULL,
                error_message TEXT NOT NULL,
                error_context JSON,
                stack_trace TEXT,
                file_path VARCHAR(500),
                line_number INT,
                user_id INT NULL,
                session_id VARCHAR(128),
                ip_address VARCHAR(45),
                user_agent TEXT,
                request_uri VARCHAR(1000),
                request_method VARCHAR(10),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_error_level (error_level),
                INDEX idx_created_at (created_at),
                INDEX idx_user_id (user_id)
            );
            
            -- Performance metrics table
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                endpoint VARCHAR(255) NOT NULL,
                method VARCHAR(10) NOT NULL,
                response_time DECIMAL(8,3) NOT NULL,
                memory_usage INT,
                cpu_usage DECIMAL(5,2),
                database_queries INT DEFAULT 0,
                database_time DECIMAL(8,3) DEFAULT 0,
                cache_hits INT DEFAULT 0,
                cache_misses INT DEFAULT 0,
                status_code INT,
                user_id INT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_endpoint (endpoint),
                INDEX idx_timestamp (timestamp),
                INDEX idx_response_time (response_time)
            );
            
            -- User activity tracking
            CREATE TABLE IF NOT EXISTS user_analytics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NULL,
                session_id VARCHAR(128) NOT NULL,
                event_type VARCHAR(100) NOT NULL,
                event_data JSON,
                page_url VARCHAR(1000),
                referrer_url VARCHAR(1000),
                ip_address VARCHAR(45),
                user_agent TEXT,
                device_type ENUM('desktop', 'mobile', 'tablet', 'unknown') DEFAULT 'unknown',
                browser VARCHAR(100),
                os VARCHAR(100),
                country VARCHAR(2),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_id (user_id),
                INDEX idx_event_type (event_type),
                INDEX idx_session_id (session_id),
                INDEX idx_created_at (created_at)
            );
            
            -- System health checks
            CREATE TABLE IF NOT EXISTS health_checks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                check_name VARCHAR(100) NOT NULL,
                status ENUM('healthy', 'degraded', 'unhealthy') NOT NULL,
                response_time DECIMAL(8,3),
                details JSON,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_check_name (check_name),
                INDEX idx_status (status),
                INDEX idx_created_at (created_at)
            );
            
            -- Alert rules table
            CREATE TABLE IF NOT EXISTS alert_rules (
                id INT AUTO_INCREMENT PRIMARY KEY,
                rule_name VARCHAR(100) NOT NULL UNIQUE,
                metric_name VARCHAR(255) NOT NULL,
                condition_operator ENUM('>', '<', '>=', '<=', '=', '!=') NOT NULL,
                threshold_value DECIMAL(15,4) NOT NULL,
                time_window_minutes INT DEFAULT 5,
                alert_channels JSON,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            );
        ";
        
        $this->pdo->exec($sql);
    }
    
    /**
     * Initialize Sentry for error tracking
     */
    private function initializeSentry() {
        if ($this->sentryDsn && $this->isProduction) {
            // Initialize Sentry (you'll need to install sentry/sentry package)
            // \Sentry\init(['dsn' => $this->sentryDsn]);
        }
    }
    
    /**
     * Track application metrics
     */
    public function trackMetric($name, $value, $type = 'counter', $tags = []) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO app_metrics (metric_name, metric_value, metric_type, tags)
                VALUES (?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $name,
                $value,
                $type,
                json_encode($tags)
            ]);
            
            // Also send to Redis for real-time monitoring if available
            if ($this->redis) {
                $key = "metrics:{$name}:" . date('Y-m-d-H-i');
                $this->redis->incrBy($key, $value);
                $this->redis->expire($key, 3600); // Keep for 1 hour
            }
            
        } catch (Exception $e) {
            error_log("Failed to track metric: " . $e->getMessage());
        }
    }
    
    /**
     * Log errors with full context
     */
    public function logError($level, $message, $context = [], $exception = null) {
        try {
            $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 3);
            $caller = $backtrace[1] ?? $backtrace[0];
            
            $errorData = [
                'error_level' => $level,
                'error_message' => $message,
                'error_context' => json_encode($context),
                'stack_trace' => $exception ? $exception->getTraceAsString() : json_encode($backtrace),
                'file_path' => $caller['file'] ?? null,
                'line_number' => $caller['line'] ?? null,
                'user_id' => $_SESSION['user_id'] ?? null,
                'session_id' => session_id(),
                'ip_address' => $this->getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                'request_uri' => $_SERVER['REQUEST_URI'] ?? null,
                'request_method' => $_SERVER['REQUEST_METHOD'] ?? null
            ];
            
            $stmt = $this->pdo->prepare("
                INSERT INTO error_logs 
                (error_level, error_message, error_context, stack_trace, file_path, line_number,
                 user_id, session_id, ip_address, user_agent, request_uri, request_method)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute(array_values($errorData));
            
            // Send to Sentry in production
            if ($this->isProduction && $exception) {
                // \Sentry\captureException($exception);
            }
            
            // Track error metric
            $this->trackMetric('errors.total', 1, 'counter', [
                'level' => $level,
                'file' => basename($caller['file'] ?? 'unknown')
            ]);
            
        } catch (Exception $e) {
            error_log("Failed to log error: " . $e->getMessage());
        }
    }
    
    /**
     * Track performance metrics
     */
    public function trackPerformance($endpoint, $method, $startTime, $additionalMetrics = []) {
        try {
            $responseTime = (microtime(true) - $startTime) * 1000; // Convert to milliseconds
            $memoryUsage = memory_get_peak_usage(true);
            $statusCode = http_response_code() ?: 200;
            
            $performanceData = [
                'endpoint' => $endpoint,
                'method' => strtoupper($method),
                'response_time' => $responseTime,
                'memory_usage' => $memoryUsage,
                'cpu_usage' => $additionalMetrics['cpu_usage'] ?? 0,
                'database_queries' => $additionalMetrics['database_queries'] ?? 0,
                'database_time' => $additionalMetrics['database_time'] ?? 0,
                'cache_hits' => $additionalMetrics['cache_hits'] ?? 0,
                'cache_misses' => $additionalMetrics['cache_misses'] ?? 0,
                'status_code' => $statusCode,
                'user_id' => $_SESSION['user_id'] ?? null
            ];
            
            $stmt = $this->pdo->prepare("
                INSERT INTO performance_metrics 
                (endpoint, method, response_time, memory_usage, cpu_usage, 
                 database_queries, database_time, cache_hits, cache_misses, 
                 status_code, user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute(array_values($performanceData));
            
            // Track performance metrics
            $this->trackMetric('response_time', $responseTime, 'timer', [
                'endpoint' => $endpoint,
                'method' => $method
            ]);
            
            $this->trackMetric('memory_usage', $memoryUsage, 'gauge');
            
            // Alert on slow responses
            if ($responseTime > 2000) { // > 2 seconds
                $this->triggerAlert('slow_response', [
                    'endpoint' => $endpoint,
                    'response_time' => $responseTime
                ]);
            }
            
        } catch (Exception $e) {
            error_log("Failed to track performance: " . $e->getMessage());
        }
    }
    
    /**
     * Track user analytics events
     */
    public function trackUserEvent($eventType, $eventData = [], $userId = null) {
        try {
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $deviceInfo = $this->parseUserAgent($userAgent);
            
            $analyticsData = [
                'user_id' => $userId ?? ($_SESSION['user_id'] ?? null),
                'session_id' => session_id(),
                'event_type' => $eventType,
                'event_data' => json_encode($eventData),
                'page_url' => $_SERVER['REQUEST_URI'] ?? null,
                'referrer_url' => $_SERVER['HTTP_REFERER'] ?? null,
                'ip_address' => $this->getClientIP(),
                'user_agent' => $userAgent,
                'device_type' => $deviceInfo['device_type'],
                'browser' => $deviceInfo['browser'],
                'os' => $deviceInfo['os'],
                'country' => $this->getCountryFromIP($this->getClientIP())
            ];
            
            $stmt = $this->pdo->prepare("
                INSERT INTO user_analytics 
                (user_id, session_id, event_type, event_data, page_url, referrer_url,
                 ip_address, user_agent, device_type, browser, os, country)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute(array_values($analyticsData));
            
            // Track event metrics
            $this->trackMetric('user_events.total', 1, 'counter', [
                'event_type' => $eventType,
                'device_type' => $deviceInfo['device_type']
            ]);
            
        } catch (Exception $e) {
            error_log("Failed to track user event: " . $e->getMessage());
        }
    }
    
    /**
     * Perform health checks
     */
    public function performHealthChecks() {
        $checks = [
            'database' => [$this, 'checkDatabase'],
            'redis' => [$this, 'checkRedis'],
            'disk_space' => [$this, 'checkDiskSpace'],
            'memory' => [$this, 'checkMemory'],
            'websocket' => [$this, 'checkWebSocket']
        ];
        
        $results = [];
        
        foreach ($checks as $checkName => $callback) {
            $startTime = microtime(true);
            
            try {
                $result = call_user_func($callback);
                $responseTime = (microtime(true) - $startTime) * 1000;
                
                $this->recordHealthCheck($checkName, $result['status'], $responseTime, $result['details']);
                $results[$checkName] = array_merge($result, ['response_time' => $responseTime]);
                
            } catch (Exception $e) {
                $responseTime = (microtime(true) - $startTime) * 1000;
                $this->recordHealthCheck($checkName, 'unhealthy', $responseTime, ['error' => $e->getMessage()]);
                $results[$checkName] = [
                    'status' => 'unhealthy',
                    'error' => $e->getMessage(),
                    'response_time' => $responseTime
                ];
            }
        }
        
        return $results;
    }
    
    /**
     * Get analytics dashboard data
     */
    public function getDashboardData($timeframe = '24h') {
        $timeCondition = $this->getTimeCondition($timeframe);
        
        return [
            'overview' => $this->getOverviewMetrics($timeCondition),
            'performance' => $this->getPerformanceMetrics($timeCondition),
            'errors' => $this->getErrorMetrics($timeCondition),
            'user_activity' => $this->getUserActivityMetrics($timeCondition),
            'system_health' => $this->getSystemHealth()
        ];
    }
    
    /**
     * Generate performance report
     */
    public function generateReport($type = 'daily', $date = null) {
        $date = $date ?? date('Y-m-d');
        
        switch ($type) {
            case 'daily':
                return $this->generateDailyReport($date);
            case 'weekly':
                return $this->generateWeeklyReport($date);
            case 'monthly':
                return $this->generateMonthlyReport($date);
            default:
                throw new InvalidArgumentException("Unknown report type: $type");
        }
    }
    
    // Private helper methods
    
    private function checkDatabase() {
        $stmt = $this->pdo->query("SELECT 1");
        $result = $stmt->fetch();
        
        return [
            'status' => $result ? 'healthy' : 'unhealthy',
            'details' => ['connection' => $result ? 'ok' : 'failed']
        ];
    }
    
    private function checkRedis() {
        if (!$this->redis) {
            return ['status' => 'unhealthy', 'details' => ['error' => 'Redis not configured']];
        }
        
        try {
            $this->redis->ping();
            return ['status' => 'healthy', 'details' => ['connection' => 'ok']];
        } catch (Exception $e) {
            return ['status' => 'unhealthy', 'details' => ['error' => $e->getMessage()]];
        }
    }
    
    private function checkDiskSpace() {
        $freeSpace = disk_free_space('/');
        $totalSpace = disk_total_space('/');
        $usagePercent = (($totalSpace - $freeSpace) / $totalSpace) * 100;
        
        $status = $usagePercent > 90 ? 'unhealthy' : ($usagePercent > 80 ? 'degraded' : 'healthy');
        
        return [
            'status' => $status,
            'details' => [
                'usage_percent' => round($usagePercent, 2),
                'free_space_gb' => round($freeSpace / 1024 / 1024 / 1024, 2)
            ]
        ];
    }
    
    private function checkMemory() {
        $memoryUsage = memory_get_usage(true);
        $memoryLimit = ini_get('memory_limit');
        $memoryLimitBytes = $this->convertToBytes($memoryLimit);
        $usagePercent = ($memoryUsage / $memoryLimitBytes) * 100;
        
        $status = $usagePercent > 90 ? 'unhealthy' : ($usagePercent > 80 ? 'degraded' : 'healthy');
        
        return [
            'status' => $status,
            'details' => [
                'usage_percent' => round($usagePercent, 2),
                'memory_usage_mb' => round($memoryUsage / 1024 / 1024, 2)
            ]
        ];
    }
    
    private function checkWebSocket() {
        $websocketUrl = 'http://localhost:3001/health';
        $context = stream_context_create(['http' => ['timeout' => 5]]);
        $result = @file_get_contents($websocketUrl, false, $context);
        
        return [
            'status' => $result ? 'healthy' : 'unhealthy',
            'details' => ['response' => $result ?: 'No response']
        ];
    }
    
    private function recordHealthCheck($checkName, $status, $responseTime, $details) {
        $stmt = $this->pdo->prepare("
            INSERT INTO health_checks (check_name, status, response_time, details)
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $checkName,
            $status,
            $responseTime,
            json_encode($details)
        ]);
    }
    
    private function getClientIP() {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                return trim($ips[0]);
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    private function parseUserAgent($userAgent) {
        // Simplified user agent parsing
        $deviceType = 'desktop';
        $browser = 'unknown';
        $os = 'unknown';
        
        if (preg_match('/Mobile|Android|iPhone|iPad/', $userAgent)) {
            $deviceType = 'mobile';
        } elseif (preg_match('/Tablet|iPad/', $userAgent)) {
            $deviceType = 'tablet';
        }
        
        if (preg_match('/Firefox/i', $userAgent)) {
            $browser = 'Firefox';
        } elseif (preg_match('/Chrome/i', $userAgent)) {
            $browser = 'Chrome';
        } elseif (preg_match('/Safari/i', $userAgent)) {
            $browser = 'Safari';
        } elseif (preg_match('/Edge/i', $userAgent)) {
            $browser = 'Edge';
        }
        
        if (preg_match('/Windows/i', $userAgent)) {
            $os = 'Windows';
        } elseif (preg_match('/Mac/i', $userAgent)) {
            $os = 'macOS';
        } elseif (preg_match('/Linux/i', $userAgent)) {
            $os = 'Linux';
        } elseif (preg_match('/Android/i', $userAgent)) {
            $os = 'Android';
        } elseif (preg_match('/iOS/i', $userAgent)) {
            $os = 'iOS';
        }
        
        return [
            'device_type' => $deviceType,
            'browser' => $browser,
            'os' => $os
        ];
    }
    
    private function getCountryFromIP($ip) {
        // Simplified - you'd want to use a proper GeoIP service
        return 'US'; // Default
    }
    
    private function convertToBytes($value) {
        $unit = strtolower(substr($value, -1));
        $value = (int) $value;
        
        switch ($unit) {
            case 'g': $value *= 1024;
            case 'm': $value *= 1024;
            case 'k': $value *= 1024;
        }
        
        return $value;
    }
    
    private function getTimeCondition($timeframe) {
        switch ($timeframe) {
            case '1h': return "created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
            case '24h': return "created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
            case '7d': return "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case '30d': return "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default: return "created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
        }
    }
    
    private function getOverviewMetrics($timeCondition) {
        $stmt = $this->pdo->query("
            SELECT 
                COUNT(*) as total_requests,
                AVG(response_time) as avg_response_time,
                COUNT(CASE WHEN status_code >= 400 THEN 1 END) as error_count
            FROM performance_metrics 
            WHERE $timeCondition
        ");
        
        return $stmt->fetch();
    }
    
    private function getPerformanceMetrics($timeCondition) {
        $stmt = $this->pdo->query("
            SELECT 
                endpoint,
                COUNT(*) as request_count,
                AVG(response_time) as avg_response_time,
                MAX(response_time) as max_response_time,
                AVG(memory_usage) as avg_memory_usage
            FROM performance_metrics 
            WHERE $timeCondition
            GROUP BY endpoint
            ORDER BY request_count DESC
            LIMIT 10
        ");
        
        return $stmt->fetchAll();
    }
    
    private function getErrorMetrics($timeCondition) {
        $stmt = $this->pdo->query("
            SELECT 
                error_level,
                COUNT(*) as error_count
            FROM error_logs 
            WHERE $timeCondition
            GROUP BY error_level
            ORDER BY error_count DESC
        ");
        
        return $stmt->fetchAll();
    }
    
    private function getUserActivityMetrics($timeCondition) {
        $stmt = $this->pdo->query("
            SELECT 
                event_type,
                COUNT(*) as event_count,
                COUNT(DISTINCT user_id) as unique_users
            FROM user_analytics 
            WHERE $timeCondition
            GROUP BY event_type
            ORDER BY event_count DESC
            LIMIT 10
        ");
        
        return $stmt->fetchAll();
    }
    
    private function getSystemHealth() {
        $stmt = $this->pdo->query("
            SELECT 
                check_name,
                status,
                AVG(response_time) as avg_response_time
            FROM health_checks 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            GROUP BY check_name, status
            ORDER BY created_at DESC
        ");
        
        return $stmt->fetchAll();
    }
    
    private function triggerAlert($alertType, $details) {
        // Implement alert triggering logic
        // This could send emails, Slack notifications, etc.
        error_log("ALERT: $alertType - " . json_encode($details));
    }
    
    private function generateDailyReport($date) {
        // Implementation for daily report generation
        return ['type' => 'daily', 'date' => $date, 'data' => []];
    }
    
    private function generateWeeklyReport($date) {
        // Implementation for weekly report generation
        return ['type' => 'weekly', 'date' => $date, 'data' => []];
    }
    
    private function generateMonthlyReport($date) {
        // Implementation for monthly report generation
        return ['type' => 'monthly', 'date' => $date, 'data' => []];
    }
}

// Global error handler integration
function setupMonitoringErrorHandler($monitoring) {
    set_error_handler(function($severity, $message, $file, $line) use ($monitoring) {
        $level = match($severity) {
            E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR => 'error',
            E_WARNING, E_CORE_WARNING, E_COMPILE_WARNING, E_USER_WARNING => 'warning',
            E_NOTICE, E_USER_NOTICE => 'notice',
            E_DEPRECATED, E_USER_DEPRECATED => 'warning',
            default => 'error'
        };
        
        $monitoring->logError($level, $message, [
            'file' => $file,
            'line' => $line,
            'severity' => $severity
        ]);
        
        return false; // Let PHP handle the error normally
    });
    
    set_exception_handler(function($exception) use ($monitoring) {
        $monitoring->logError('error', $exception->getMessage(), [
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'code' => $exception->getCode()
        ], $exception);
    });
}
?>
