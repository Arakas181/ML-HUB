<?php
// Home page content
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <h1 class="display-4 fw-bold mb-4">Welcome to Esports Platform</h1>
                <p class="lead mb-5">Join the ultimate competitive gaming community. Participate in tournaments, connect with players, and showcase your skills.</p>
                <div class="d-flex justify-content-center gap-3">
                    <?php if (!isLoggedIn()): ?>
                        <a href="?page=register" class="btn btn-primary btn-lg px-5">Get Started</a>
                        <a href="?page=tournaments" class="btn btn-outline-light btn-lg px-5">View Tournaments</a>
                    <?php else: ?>
                        <a href="?page=dashboard" class="btn btn-primary btn-lg px-5">My Dashboard</a>
                        <a href="?page=tournaments" class="btn btn-outline-light btn-lg px-5">Browse Tournaments</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5">
    <div class="container">
        <div class="row text-center mb-5">
            <div class="col-lg-8 mx-auto">
                <h2 class="display-5 fw-bold mb-3">Why Choose Our Platform?</h2>
                <p class="lead">Experience competitive gaming like never before with our comprehensive esports platform.</p>
            </div>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card h-100 text-center p-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-trophy fa-3x text-primary"></i>
                        </div>
                        <h4 class="card-title">Tournaments</h4>
                        <p class="card-text">Join competitive tournaments with players from around the world. Compete for prizes and glory.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 text-center p-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-users fa-3x text-primary"></i>
                        </div>
                        <h4 class="card-title">Community</h4>
                        <p class="card-text">Connect with like-minded gamers, form teams, and build lasting friendships in our vibrant community.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 text-center p-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-chart-line fa-3x text-primary"></i>
                        </div>
                        <h4 class="card-title">Rankings</h4>
                        <p class="card-text">Track your progress, climb the leaderboards, and establish yourself as a top competitor.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Recent Tournaments Section -->
<section class="py-5 bg-dark">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="display-5 fw-bold mb-3">Featured Tournaments</h2>
                <p class="lead">Check out our latest and most popular tournaments.</p>
            </div>
        </div>
        
        <div class="row g-4">
            <?php
            try {
                $stmt = $pdo->prepare("
                    SELECT t.*, 
                           (SELECT COUNT(*) FROM tournament_participants tp WHERE tp.tournament_id = t.id) as participant_count
                    FROM tournaments t 
                    WHERE t.status IN ('upcoming', 'ongoing')
                    ORDER BY t.start_date ASC 
                    LIMIT 3
                ");
                $stmt->execute();
                $tournaments = $stmt->fetchAll();
                
                if (empty($tournaments)): ?>
                    <div class="col-12 text-center">
                        <div class="card p-5">
                            <div class="card-body">
                                <i class="fas fa-calendar-plus fa-3x text-muted mb-3"></i>
                                <h4>No Active Tournaments</h4>
                                <p class="text-muted">New tournaments are coming soon! Stay tuned.</p>
                                <?php if (isLoggedIn() && in_array($currentUser['role'], ['admin', 'super_admin'])): ?>
                                    <a href="?page=admin&action=create_tournament" class="btn btn-primary">Create Tournament</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach ($tournaments as $tournament): ?>
                        <div class="col-lg-4">
                            <div class="card tournament-card h-100">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><?php echo htmlspecialchars($tournament['name']); ?></h5>
                                    <span class="badge <?php echo $tournament['status'] == 'ongoing' ? 'bg-success' : 'bg-primary'; ?> status-badge">
                                        <?php echo ucfirst($tournament['status']); ?>
                                    </span>
                                </div>
                                <div class="card-body">
                                    <p class="card-text"><?php echo htmlspecialchars(substr($tournament['description'] ?? '', 0, 100)) . '...'; ?></p>
                                    
                                    <div class="mb-3">
                                        <small class="text-muted">
                                            <i class="fas fa-calendar"></i> 
                                            <?php echo date('M j, Y', strtotime($tournament['start_date'])); ?>
                                        </small>
                                        <br>
                                        <small class="text-muted">
                                            <i class="fas fa-users"></i> 
                                            <?php echo $tournament['participant_count']; ?> participants
                                        </small>
                                    </div>
                                    
                                    <?php if ($tournament['prize_pool'] > 0): ?>
                                        <div class="mb-3">
                                            <span class="badge bg-warning text-dark">
                                                <i class="fas fa-dollar-sign"></i> $<?php echo number_format($tournament['prize_pool']); ?> Prize Pool
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-footer">
                                    <a href="?page=tournament&id=<?php echo $tournament['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                                    <?php if (isLoggedIn() && $tournament['status'] == 'upcoming'): ?>
                                        <a href="?page=tournament&id=<?php echo $tournament['id']; ?>&action=register" class="btn btn-success btn-sm">Register</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
            <?php } catch (Exception $e): ?>
                <div class="col-12 text-center">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        Unable to load tournaments at the moment. Please try again later.
                    </div>
                </div>
            <?php endtry; ?>
        </div>
        
        <div class="text-center mt-5">
            <a href="?page=tournaments" class="btn btn-outline-primary btn-lg">View All Tournaments</a>
        </div>
    </div>
</section>

<!-- Call to Action -->
<?php if (!isLoggedIn()): ?>
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="display-5 fw-bold mb-3">Ready to Start Your Journey?</h2>
                <p class="lead mb-4">Join thousands of gamers competing in exciting tournaments and building their esports careers.</p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="?page=register" class="btn btn-primary btn-lg px-5">Sign Up Now</a>
                    <a href="?page=about" class="btn btn-outline-primary btn-lg px-5">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Stats Section -->
<section class="py-5 bg-dark">
    <div class="container">
        <div class="row text-center">
            <?php
            try {
                // Get platform statistics
                $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
                $tournamentCount = $pdo->query("SELECT COUNT(*) FROM tournaments")->fetchColumn();
                $matchCount = $pdo->query("SELECT COUNT(*) FROM matches")->fetchColumn();
                $totalPrizePool = $pdo->query("SELECT SUM(prize_pool) FROM tournaments WHERE prize_pool > 0")->fetchColumn();
            } catch (Exception $e) {
                $userCount = $tournamentCount = $matchCount = $totalPrizePool = 0;
            }
            ?>
            
            <div class="col-6 col-lg-3 mb-4">
                <div class="card bg-transparent border-0 text-center">
                    <div class="card-body">
                        <h2 class="display-6 fw-bold text-primary"><?php echo number_format($userCount); ?>+</h2>
                        <p class="text-muted mb-0">Active Players</p>
                    </div>
                </div>
            </div>
            
            <div class="col-6 col-lg-3 mb-4">
                <div class="card bg-transparent border-0 text-center">
                    <div class="card-body">
                        <h2 class="display-6 fw-bold text-primary"><?php echo number_format($tournamentCount); ?>+</h2>
                        <p class="text-muted mb-0">Tournaments</p>
                    </div>
                </div>
            </div>
            
            <div class="col-6 col-lg-3 mb-4">
                <div class="card bg-transparent border-0 text-center">
                    <div class="card-body">
                        <h2 class="display-6 fw-bold text-primary"><?php echo number_format($matchCount); ?>+</h2>
                        <p class="text-muted mb-0">Matches Played</p>
                    </div>
                </div>
            </div>
            
            <div class="col-6 col-lg-3 mb-4">
                <div class="card bg-transparent border-0 text-center">
                    <div class="card-body">
                        <h2 class="display-6 fw-bold text-primary">$<?php echo number_format($totalPrizePool ?? 0); ?>+</h2>
                        <p class="text-muted mb-0">Total Prizes</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
