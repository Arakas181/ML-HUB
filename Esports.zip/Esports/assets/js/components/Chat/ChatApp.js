import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { Send, Users, Settings, Smile } from 'lucide-react';
import './ChatApp.scss';

const ChatApp = ({ roomId, userId, username, userRole }) => {
  const [socket, setSocket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [isConnected, setIsConnected] = useState(false);
  const [typing, setTyping] = useState([]);
  const messagesEndRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    // Initialize socket connection
    const newSocket = io('ws://localhost:8080', {
      transports: ['websocket'],
      upgrade: false
    });

    newSocket.on('connect', () => {
      setIsConnected(true);
      newSocket.emit('join_room', {
        roomId,
        userId,
        username,
        userRole
      });
    });

    newSocket.on('disconnect', () => {
      setIsConnected(false);
    });

    newSocket.on('message', (message) => {
      setMessages(prev => [...prev, message]);
    });

    newSocket.on('user_joined', (data) => {
      setMessages(prev => [...prev, {
        id: Date.now(),
        type: 'system',
        message: `${data.username} joined the chat`,
        timestamp: new Date()
      }]);
      setOnlineUsers(data.onlineUsers);
    });

    newSocket.on('user_left', (data) => {
      setMessages(prev => [...prev, {
        id: Date.now(),
        type: 'system',
        message: `${data.username} left the chat`,
        timestamp: new Date()
      }]);
      setOnlineUsers(data.onlineUsers);
    });

    newSocket.on('user_typing', (data) => {
      setTyping(prev => {
        if (!prev.includes(data.username)) {
          return [...prev, data.username];
        }
        return prev;
      });
    });

    newSocket.on('user_stopped_typing', (data) => {
      setTyping(prev => prev.filter(user => user !== data.username));
    });

    newSocket.on('online_users', (users) => {
      setOnlineUsers(users);
    });

    setSocket(newSocket);

    return () => newSocket.close();
  }, [roomId, userId, username, userRole]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const sendMessage = (e) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !socket || !isConnected) return;

    const message = {
      roomId,
      userId,
      username,
      userRole,
      message: newMessage.trim(),
      timestamp: new Date()
    };

    socket.emit('send_message', message);
    setNewMessage('');
    
    // Stop typing indicator
    socket.emit('stop_typing', { roomId, username });
  };

  const handleTyping = (e) => {
    setNewMessage(e.target.value);
    
    if (!socket || !isConnected) return;

    // Emit typing event
    socket.emit('typing', { roomId, username });
    
    // Clear previous timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    // Stop typing after 3 seconds
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit('stop_typing', { roomId, username });
    }, 3000);
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getRoleColor = (role) => {
    const colors = {
      'super_admin': '#ff6b6b',
      'admin': '#4ecdc4',
      'squad_leader': '#45b7d1',
      'user': '#96ceb4'
    };
    return colors[role] || colors.user;
  };

  const MessageComponent = ({ message }) => {
    const isOwnMessage = message.userId === userId;
    const isSystem = message.type === 'system';
    
    if (isSystem) {
      return (
        <div className="system-message">
          <span className="system-text">{message.message}</span>
          <span className="message-time">{formatTime(message.timestamp)}</span>
        </div>
      );
    }
    
    return (
      <div className={`message ${isOwnMessage ? 'own-message' : 'other-message'}`}>
        <div className="message-header">
          <span 
            className="username" 
            style={{ color: getRoleColor(message.userRole) }}
          >
            {message.username}
          </span>
          <span className="role-badge" data-role={message.userRole}>
            {message.userRole.replace('_', ' ')}
          </span>
          <span className="message-time">{formatTime(message.timestamp)}</span>
        </div>
        <div className="message-content">
          {message.message}
        </div>
      </div>
    );
  };

  return (
    <div className="chat-app">
      <div className="chat-header">
        <div className="chat-title">
          <h3>Live Chat</h3>
          <div className={`connection-status ${isConnected ? 'connected' : 'disconnected'}`}>
            {isConnected ? '🟢 Connected' : '🔴 Disconnected'}
          </div>
        </div>
        
        <div className="chat-actions">
          <button className="online-users-btn" title="Online Users">
            <Users size={18} />
            <span>{onlineUsers.length}</span>
          </button>
          <button className="chat-settings-btn" title="Settings">
            <Settings size={18} />
          </button>
        </div>
      </div>

      <div className="online-users-sidebar">
        <h4>Online Users ({onlineUsers.length})</h4>
        <div className="users-list">
          {onlineUsers.map((user, index) => (
            <div key={index} className="online-user">
              <div className="user-avatar">
                {user.username.charAt(0).toUpperCase()}
              </div>
              <div className="user-info">
                <span className="user-name">{user.username}</span>
                <span 
                  className="user-role"
                  style={{ color: getRoleColor(user.role) }}
                >
                  {user.role.replace('_', ' ')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="chat-messages">
        <div className="messages-container">
          {messages.map((message) => (
            <MessageComponent key={message.id || message.timestamp} message={message} />
          ))}
          
          {typing.length > 0 && (
            <div className="typing-indicator">
              <span className="typing-text">
                {typing.join(', ')} {typing.length === 1 ? 'is' : 'are'} typing...
              </span>
              <div className="typing-dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      <form className="chat-input-form" onSubmit={sendMessage}>
        <div className="input-container">
          <button type="button" className="emoji-btn" title="Add Emoji">
            <Smile size={18} />
          </button>
          
          <input
            type="text"
            value={newMessage}
            onChange={handleTyping}
            placeholder="Type your message..."
            className="message-input"
            maxLength={500}
            disabled={!isConnected}
          />
          
          <button 
            type="submit" 
            className="send-btn"
            disabled={!newMessage.trim() || !isConnected}
            title="Send Message"
          >
            <Send size={18} />
          </button>
        </div>
        
        <div className="input-footer">
          <span className="char-count">
            {newMessage.length}/500
          </span>
          {!isConnected && (
            <span className="connection-warning">
              Reconnecting...
            </span>
          )}
        </div>
      </form>
    </div>
  );
};

export default ChatApp;
