<?php
/**
 * API Router for Esports Platform v1
 * Handles routing, authentication, and response formatting
 */

require_once '../../config.php';
require_once '../../includes/SecurityMiddleware.php';

class APIRouter {
    private $pdo;
    private $security;
    private $routes = [];
    private $middleware = [];
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->security = new SecurityMiddleware($pdo);
        $this->initializeRoutes();
    }
    
    /**
     * Initialize API routes
     */
    private function initializeRoutes() {
        // Authentication routes
        $this->addRoute('POST', '/auth/login', 'AuthController::login');
        $this->addRoute('POST', '/auth/logout', 'AuthController::logout', ['auth']);
        $this->addRoute('POST', '/auth/refresh', 'AuthController::refresh', ['auth']);
        $this->addRoute('POST', '/auth/register', 'AuthController::register');
        
        // User routes
        $this->addRoute('GET', '/users', 'UserController::index', ['auth']);
        $this->addRoute('GET', '/users/{id}', 'UserController::show', ['auth']);
        $this->addRoute('PUT', '/users/{id}', 'UserController::update', ['auth']);
        $this->addRoute('DELETE', '/users/{id}', 'UserController::delete', ['auth', 'admin']);
        
        // Tournament routes
        $this->addRoute('GET', '/tournaments', 'TournamentController::index');
        $this->addRoute('GET', '/tournaments/{id}', 'TournamentController::show');
        $this->addRoute('POST', '/tournaments', 'TournamentController::create', ['auth', 'admin']);
        $this->addRoute('PUT', '/tournaments/{id}', 'TournamentController::update', ['auth', 'admin']);
        $this->addRoute('DELETE', '/tournaments/{id}', 'TournamentController::delete', ['auth', 'admin']);
        $this->addRoute('POST', '/tournaments/{id}/register', 'TournamentController::register', ['auth']);
        
        // Match routes
        $this->addRoute('GET', '/matches', 'MatchController::index');
        $this->addRoute('GET', '/matches/{id}', 'MatchController::show');
        $this->addRoute('PUT', '/matches/{id}/score', 'MatchController::updateScore', ['auth', 'admin']);
        
        // Squad routes
        $this->addRoute('GET', '/squads', 'SquadController::index');
        $this->addRoute('GET', '/squads/{id}', 'SquadController::show');
        $this->addRoute('POST', '/squads', 'SquadController::create', ['auth']);
        $this->addRoute('PUT', '/squads/{id}', 'SquadController::update', ['auth']);
        $this->addRoute('POST', '/squads/{id}/join', 'SquadController::join', ['auth']);
        
        // Chat routes
        $this->addRoute('GET', '/chat/rooms', 'ChatController::getRooms', ['auth']);
        $this->addRoute('GET', '/chat/rooms/{id}/messages', 'ChatController::getMessages', ['auth']);
        $this->addRoute('POST', '/chat/rooms/{id}/messages', 'ChatController::sendMessage', ['auth']);
        
        // Live streaming routes
        $this->addRoute('GET', '/streams', 'StreamController::index');
        $this->addRoute('GET', '/streams/{id}', 'StreamController::show');
        $this->addRoute('POST', '/streams', 'StreamController::create', ['auth']);
        $this->addRoute('PUT', '/streams/{id}/status', 'StreamController::updateStatus', ['auth']);
        
        // Polls routes
        $this->addRoute('GET', '/polls', 'PollController::index');
        $this->addRoute('POST', '/polls', 'PollController::create', ['auth', 'admin']);
        $this->addRoute('POST', '/polls/{id}/vote', 'PollController::vote', ['auth']);
        
        // Analytics routes
        $this->addRoute('GET', '/analytics/dashboard', 'AnalyticsController::dashboard', ['auth', 'admin']);
        $this->addRoute('GET', '/analytics/tournaments/{id}', 'AnalyticsController::tournament', ['auth', 'admin']);
    }
    
    /**
     * Add a route to the router
     */
    private function addRoute($method, $path, $handler, $middleware = []) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'middleware' => $middleware
        ];
    }
    
    /**
     * Handle incoming request
     */
    public function handleRequest() {
        // Add security headers
        $this->security->addSecurityHeaders();
        
        // Set JSON content type
        header('Content-Type: application/json');
        
        // Handle CORS for API
        $this->handleCORS();
        
        // Check rate limiting
        if (!$this->security->checkRateLimit(null, 200)) { // Higher limit for API
            $this->sendError(429, 'Rate limit exceeded');
            return;
        }
        
        try {
            $method = $_SERVER['REQUEST_METHOD'];
            $path = $this->getPath();
            
            // Find matching route
            $route = $this->findRoute($method, $path);
            
            if (!$route) {
                $this->sendError(404, 'Endpoint not found');
                return;
            }
            
            // Check middleware
            if (!$this->checkMiddleware($route['middleware'])) {
                return;
            }
            
            // Execute route handler
            $this->executeHandler($route['handler'], $route['params'] ?? []);
            
        } catch (Exception $e) {
            error_log("API Error: " . $e->getMessage());
            $this->sendError(500, 'Internal server error');
        }
    }
    
    /**
     * Handle CORS for API requests
     */
    private function handleCORS() {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowedOrigins = [
            'http://localhost:3000',
            'http://localhost:8080',
            'https://yourdomain.com'
        ];
        
        if (in_array($origin, $allowedOrigins)) {
            header("Access-Control-Allow-Origin: $origin");
        }
        
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');
        header('Access-Control-Allow-Credentials: true');
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit();
        }
    }
    
    /**
     * Get the request path
     */
    private function getPath() {
        $path = $_SERVER['REQUEST_URI'];
        $path = parse_url($path, PHP_URL_PATH);
        $path = str_replace('/api/v1', '', $path);
        return $path ?: '/';
    }
    
    /**
     * Find matching route
     */
    private function findRoute($method, $path) {
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) continue;
            
            $pattern = preg_replace('/\{([^}]+)\}/', '([^/]+)', $route['path']);
            $pattern = "#^{$pattern}$#";
            
            if (preg_match($pattern, $path, $matches)) {
                array_shift($matches); // Remove full match
                $route['params'] = $matches;
                return $route;
            }
        }
        
        return null;
    }
    
    /**
     * Check middleware requirements
     */
    private function checkMiddleware($middlewares) {
        foreach ($middlewares as $middleware) {
            switch ($middleware) {
                case 'auth':
                    if (!$this->checkAuthentication()) {
                        $this->sendError(401, 'Authentication required');
                        return false;
                    }
                    break;
                    
                case 'admin':
                    if (!$this->checkAdminRole()) {
                        $this->sendError(403, 'Admin access required');
                        return false;
                    }
                    break;
            }
        }
        
        return true;
    }
    
    /**
     * Check if user is authenticated
     */
    private function checkAuthentication() {
        $token = $this->getBearerToken();
        
        if (!$token) {
            return false;
        }
        
        // Verify JWT token (you'll need to implement JWT handling)
        $userData = $this->verifyJWT($token);
        
        if ($userData) {
            $_SESSION['user_id'] = $userData['user_id'];
            $_SESSION['role'] = $userData['role'];
            return true;
        }
        
        return false;
    }
    
    /**
     * Check if user has admin role
     */
    private function checkAdminRole() {
        $role = $_SESSION['role'] ?? '';
        return in_array($role, ['admin', 'super_admin']);
    }
    
    /**
     * Get bearer token from header
     */
    private function getBearerToken() {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? '';
        
        if (strpos($authHeader, 'Bearer ') === 0) {
            return substr($authHeader, 7);
        }
        
        return null;
    }
    
    /**
     * Verify JWT token (simplified version)
     */
    private function verifyJWT($token) {
        // This is a simplified version. In production, use a proper JWT library
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }
            
            $payload = json_decode(base64_decode($parts[1]), true);
            
            // Check expiration
            if ($payload['exp'] < time()) {
                return false;
            }
            
            // Verify user exists
            $stmt = $this->pdo->prepare("SELECT id, role FROM users WHERE id = ?");
            $stmt->execute([$payload['user_id']]);
            $user = $stmt->fetch();
            
            if ($user) {
                return [
                    'user_id' => $user['id'],
                    'role' => $user['role']
                ];
            }
            
        } catch (Exception $e) {
            return false;
        }
        
        return false;
    }
    
    /**
     * Execute route handler
     */
    private function executeHandler($handler, $params = []) {
        list($controller, $method) = explode('::', $handler);
        
        $controllerFile = __DIR__ . "/controllers/{$controller}.php";
        
        if (!file_exists($controllerFile)) {
            $this->sendError(500, 'Controller not found');
            return;
        }
        
        require_once $controllerFile;
        
        $controllerInstance = new $controller($this->pdo);
        
        if (!method_exists($controllerInstance, $method)) {
            $this->sendError(500, 'Method not found');
            return;
        }
        
        $controllerInstance->$method($params);
    }
    
    /**
     * Send JSON response
     */
    public function sendResponse($data, $status = 200) {
        http_response_code($status);
        echo json_encode([
            'success' => true,
            'data' => $data,
            'timestamp' => date('c')
        ]);
    }
    
    /**
     * Send error response
     */
    public function sendError($status, $message, $errors = null) {
        http_response_code($status);
        $response = [
            'success' => false,
            'error' => $message,
            'timestamp' => date('c')
        ];
        
        if ($errors) {
            $response['errors'] = $errors;
        }
        
        echo json_encode($response);
    }
}

// Initialize and handle request
if (!isset($pdo)) {
    require_once '../../config.php';
}

$router = new APIRouter($pdo);
$router->handleRequest();
?>
