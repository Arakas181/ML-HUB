<?php
/**
 * Tournament API Controller
 * Handles tournament-related API endpoints
 */

class TournamentController {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Get all tournaments with filtering and pagination
     */
    public function index($params = []) {
        try {
            $page = (int)($_GET['page'] ?? 1);
            $limit = min((int)($_GET['limit'] ?? 10), 100); // Max 100 items per page
            $offset = ($page - 1) * $limit;
            
            $status = $_GET['status'] ?? null;
            $search = $_GET['search'] ?? null;
            $upcoming = $_GET['upcoming'] ?? null;
            
            // Build query
            $where = ['1=1'];
            $params = [];
            
            if ($status) {
                $where[] = 'status = ?';
                $params[] = $status;
            }
            
            if ($search) {
                $where[] = '(name LIKE ? OR description LIKE ?)';
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if ($upcoming) {
                $where[] = 'start_date >= CURDATE()';
            }
            
            $whereClause = implode(' AND ', $where);
            
            // Get total count
            $countStmt = $this->pdo->prepare("
                SELECT COUNT(*) as total FROM tournaments 
                WHERE $whereClause
            ");
            $countStmt->execute($params);
            $total = $countStmt->fetch()['total'];
            
            // Get tournaments
            $stmt = $this->pdo->prepare("
                SELECT t.*, 
                       u.username as creator_name,
                       (SELECT COUNT(*) FROM tournament_participants tp WHERE tp.tournament_id = t.id) as participant_count
                FROM tournaments t 
                LEFT JOIN users u ON t.created_by = u.id 
                WHERE $whereClause
                ORDER BY t.created_at DESC 
                LIMIT ? OFFSET ?
            ");
            
            $stmt->execute([...$params, $limit, $offset]);
            $tournaments = $stmt->fetchAll();
            
            // Calculate pagination
            $totalPages = ceil($total / $limit);
            
            $this->sendResponse([
                'tournaments' => $tournaments,
                'pagination' => [
                    'current_page' => $page,
                    'total_pages' => $totalPages,
                    'total_items' => $total,
                    'per_page' => $limit,
                    'has_next' => $page < $totalPages,
                    'has_prev' => $page > 1
                ]
            ]);
            
        } catch (Exception $e) {
            $this->sendError(500, 'Failed to fetch tournaments');
        }
    }
    
    /**
     * Get single tournament with full details
     */
    public function show($params) {
        try {
            $tournamentId = $params[0];
            
            $stmt = $this->pdo->prepare("
                SELECT t.*, 
                       u.username as creator_name,
                       (SELECT COUNT(*) FROM tournament_participants tp WHERE tp.tournament_id = t.id) as participant_count
                FROM tournaments t 
                LEFT JOIN users u ON t.created_by = u.id 
                WHERE t.id = ?
            ");
            $stmt->execute([$tournamentId]);
            $tournament = $stmt->fetch();
            
            if (!$tournament) {
                $this->sendError(404, 'Tournament not found');
                return;
            }
            
            // Get participants
            $participantsStmt = $this->pdo->prepare("
                SELECT tp.*, u.username, u.avatar_url 
                FROM tournament_participants tp 
                JOIN users u ON tp.user_id = u.id 
                WHERE tp.tournament_id = ? 
                ORDER BY tp.registration_date
            ");
            $participantsStmt->execute([$tournamentId]);
            $tournament['participants'] = $participantsStmt->fetchAll();
            
            // Get matches if tournament is ongoing or completed
            if (in_array($tournament['status'], ['ongoing', 'completed'])) {
                $matchesStmt = $this->pdo->prepare("
                    SELECT m.*, 
                           t1.name as team1_name, 
                           t2.name as team2_name
                    FROM matches m 
                    LEFT JOIN teams t1 ON m.team1_id = t1.id 
                    LEFT JOIN teams t2 ON m.team2_id = t2.id 
                    WHERE m.tournament_id = ? 
                    ORDER BY m.scheduled_time
                ");
                $matchesStmt->execute([$tournamentId]);
                $tournament['matches'] = $matchesStmt->fetchAll();
            }
            
            $this->sendResponse($tournament);
            
        } catch (Exception $e) {
            $this->sendError(500, 'Failed to fetch tournament');
        }
    }
    
    /**
     * Create new tournament
     */
    public function create($params = []) {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Validation rules
            $rules = [
                'name' => ['required' => true, 'max_length' => 100],
                'description' => ['max_length' => 1000],
                'start_date' => ['required' => true],
                'end_date' => ['required' => true],
                'bracket_type' => ['required' => true],
                'max_participants' => ['type' => 'int'],
                'prize_pool' => ['type' => 'float'],
                'entry_fee' => ['type' => 'float']
            ];
            
            $errors = $this->validateInput($input, $rules);
            if (!empty($errors)) {
                $this->sendError(422, 'Validation failed', $errors);
                return;
            }
            
            // Additional validation
            if (strtotime($input['start_date']) <= time()) {
                $errors['start_date'] = 'Start date must be in the future';
            }
            
            if (strtotime($input['end_date']) <= strtotime($input['start_date'])) {
                $errors['end_date'] = 'End date must be after start date';
            }
            
            if (!empty($errors)) {
                $this->sendError(422, 'Validation failed', $errors);
                return;
            }
            
            $stmt = $this->pdo->prepare("
                INSERT INTO tournaments (
                    name, description, start_date, end_date, bracket_type,
                    prize_pool, max_participants, entry_fee, rules, 
                    registration_deadline, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $input['name'],
                $input['description'] ?? '',
                $input['start_date'],
                $input['end_date'],
                $input['bracket_type'],
                $input['prize_pool'] ?? 0,
                $input['max_participants'] ?? null,
                $input['entry_fee'] ?? 0,
                $input['rules'] ?? '',
                $input['registration_deadline'] ?? $input['start_date'],
                $_SESSION['user_id']
            ]);
            
            $tournamentId = $this->pdo->lastInsertId();
            
            // Fetch created tournament
            $stmt = $this->pdo->prepare("SELECT * FROM tournaments WHERE id = ?");
            $stmt->execute([$tournamentId]);
            $tournament = $stmt->fetch();
            
            $this->sendResponse($tournament, 201);
            
        } catch (Exception $e) {
            $this->sendError(500, 'Failed to create tournament');
        }
    }
    
    /**
     * Update tournament
     */
    public function update($params) {
        try {
            $tournamentId = $params[0];
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Check if tournament exists and user has permission
            $stmt = $this->pdo->prepare("
                SELECT created_by FROM tournaments WHERE id = ?
            ");
            $stmt->execute([$tournamentId]);
            $tournament = $stmt->fetch();
            
            if (!$tournament) {
                $this->sendError(404, 'Tournament not found');
                return;
            }
            
            // Check permission (creator or admin)
            if ($tournament['created_by'] != $_SESSION['user_id'] && 
                !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
                $this->sendError(403, 'Permission denied');
                return;
            }
            
            // Build update query
            $fields = [];
            $values = [];
            
            $allowedFields = [
                'name', 'description', 'start_date', 'end_date', 
                'prize_pool', 'max_participants', 'entry_fee', 'rules',
                'status', 'registration_deadline'
            ];
            
            foreach ($allowedFields as $field) {
                if (isset($input[$field])) {
                    $fields[] = "$field = ?";
                    $values[] = $input[$field];
                }
            }
            
            if (empty($fields)) {
                $this->sendError(422, 'No valid fields to update');
                return;
            }
            
            $values[] = $tournamentId;
            
            $stmt = $this->pdo->prepare("
                UPDATE tournaments 
                SET " . implode(', ', $fields) . "
                WHERE id = ?
            ");
            $stmt->execute($values);
            
            // Fetch updated tournament
            $stmt = $this->pdo->prepare("SELECT * FROM tournaments WHERE id = ?");
            $stmt->execute([$tournamentId]);
            $tournament = $stmt->fetch();
            
            $this->sendResponse($tournament);
            
        } catch (Exception $e) {
            $this->sendError(500, 'Failed to update tournament');
        }
    }
    
    /**
     * Delete tournament
     */
    public function delete($params) {
        try {
            $tournamentId = $params[0];
            
            // Check if tournament exists and user has permission
            $stmt = $this->pdo->prepare("
                SELECT created_by, status FROM tournaments WHERE id = ?
            ");
            $stmt->execute([$tournamentId]);
            $tournament = $stmt->fetch();
            
            if (!$tournament) {
                $this->sendError(404, 'Tournament not found');
                return;
            }
            
            // Check permission
            if ($tournament['created_by'] != $_SESSION['user_id'] && 
                !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
                $this->sendError(403, 'Permission denied');
                return;
            }
            
            // Don't allow deletion of ongoing tournaments
            if ($tournament['status'] === 'ongoing') {
                $this->sendError(422, 'Cannot delete ongoing tournament');
                return;
            }
            
            $stmt = $this->pdo->prepare("DELETE FROM tournaments WHERE id = ?");
            $stmt->execute([$tournamentId]);
            
            $this->sendResponse(['message' => 'Tournament deleted successfully']);
            
        } catch (Exception $e) {
            $this->sendError(500, 'Failed to delete tournament');
        }
    }
    
    /**
     * Register for tournament
     */
    public function register($params) {
        try {
            $tournamentId = $params[0];
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Check tournament exists and is open for registration
            $stmt = $this->pdo->prepare("
                SELECT *, 
                       (SELECT COUNT(*) FROM tournament_participants WHERE tournament_id = ?) as current_participants
                FROM tournaments 
                WHERE id = ? AND status = 'upcoming' 
                AND (registration_deadline IS NULL OR registration_deadline > NOW())
            ");
            $stmt->execute([$tournamentId, $tournamentId]);
            $tournament = $stmt->fetch();
            
            if (!$tournament) {
                $this->sendError(404, 'Tournament not found or registration closed');
                return;
            }
            
            // Check if max participants reached
            if ($tournament['max_participants'] && 
                $tournament['current_participants'] >= $tournament['max_participants']) {
                $this->sendError(422, 'Tournament is full');
                return;
            }
            
            // Check if already registered
            $stmt = $this->pdo->prepare("
                SELECT id FROM tournament_participants 
                WHERE tournament_id = ? AND user_id = ?
            ");
            $stmt->execute([$tournamentId, $_SESSION['user_id']]);
            
            if ($stmt->fetch()) {
                $this->sendError(422, 'Already registered for this tournament');
                return;
            }
            
            // Register user
            $stmt = $this->pdo->prepare("
                INSERT INTO tournament_participants (
                    tournament_id, user_id, squad_name, in_game_name
                ) VALUES (?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $tournamentId,
                $_SESSION['user_id'],
                $input['squad_name'] ?? 'Solo',
                $input['in_game_name'] ?? ''
            ]);
            
            $this->sendResponse([
                'message' => 'Successfully registered for tournament',
                'registration_id' => $this->pdo->lastInsertId()
            ]);
            
        } catch (Exception $e) {
            $this->sendError(500, 'Failed to register for tournament');
        }
    }
    
    /**
     * Validate input data
     */
    private function validateInput($data, $rules) {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $data[$field] ?? null;
            
            if (isset($rule['required']) && $rule['required'] && empty($value)) {
                $errors[$field] = "Field {$field} is required";
                continue;
            }
            
            if (empty($value)) continue;
            
            if (isset($rule['max_length']) && strlen($value) > $rule['max_length']) {
                $errors[$field] = "Maximum length is {$rule['max_length']} characters";
            }
            
            if (isset($rule['type'])) {
                switch ($rule['type']) {
                    case 'int':
                        if (!filter_var($value, FILTER_VALIDATE_INT)) {
                            $errors[$field] = "Invalid integer value";
                        }
                        break;
                    case 'float':
                        if (!filter_var($value, FILTER_VALIDATE_FLOAT)) {
                            $errors[$field] = "Invalid numeric value";
                        }
                        break;
                }
            }
        }
        
        return $errors;
    }
    
    /**
     * Send JSON response
     */
    private function sendResponse($data, $status = 200) {
        http_response_code($status);
        echo json_encode([
            'success' => true,
            'data' => $data,
            'timestamp' => date('c')
        ]);
    }
    
    /**
     * Send error response
     */
    private function sendError($status, $message, $errors = null) {
        http_response_code($status);
        $response = [
            'success' => false,
            'error' => $message,
            'timestamp' => date('c')
        ];
        
        if ($errors) {
            $response['errors'] = $errors;
        }
        
        echo json_encode($response);
    }
}
?>
