<?php
// Serverless-compatible database configuration
// This file can be included by serverless functions

// Database configuration from environment variables
$host = $_ENV['DB_HOST'] ?? $_SERVER['DB_HOST'] ?? 'localhost';
$dbname = $_ENV['DB_NAME'] ?? $_SERVER['DB_NAME'] ?? 'esports_platform';
$username = $_ENV['DB_USER'] ?? $_SERVER['DB_USER'] ?? 'root';
$password = $_ENV['DB_PASS'] ?? $_SERVER['DB_PASS'] ?? '';
$port = (int)($_ENV['DB_PORT'] ?? $_SERVER['DB_PORT'] ?? 3306);

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable for production

// Global PDO connection
global $pdo;

if (!isset($pdo)) {
    try {
        $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $e) {
        error_log('Database connection failed: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database connection failed']);
        exit();
    }
}

// Common headers for API responses
function setApiHeaders() {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
}

// Handle OPTIONS requests
function handleOptionsRequest() {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        exit(0);
    }
}

// Validate API key
function validateApiKey() {
    $apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
    $validApiKeys = [
        $_ENV['API_KEY_DEV'] ?? 'dev_key_123',
        $_ENV['API_KEY_TOURNAMENT'] ?? 'tournament_api_456'
    ];
    
    if (!in_array($apiKey, $validApiKeys)) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid API key']);
        exit();
    }
}
?>
