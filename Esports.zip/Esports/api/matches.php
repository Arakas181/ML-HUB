<?php
// Vercel serverless function for matches API
require_once __DIR__ . '/_shared/config.php';

// Set API headers
setApiHeaders();

// Handle OPTIONS requests
handleOptionsRequest();

// Validate API key
validateApiKey();

try {
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            handleGetMatches();
            break;
        case 'POST':
            handleCreateMatch();
            break;
        case 'PUT':
            handleUpdateMatch();
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    error_log('Match API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}

function handleGetMatches() {
    global $pdo;
    
    $id = $_GET['id'] ?? null;
    $tournament_id = $_GET['tournament_id'] ?? null;
    
    if ($id) {
        $stmt = $pdo->prepare("
            SELECT m.*, t.name as tournament_name
            FROM matches m
            LEFT JOIN tournaments t ON m.tournament_id = t.id
            WHERE m.id = ?
        ");
        $stmt->execute([$id]);
        $match = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$match) {
            http_response_code(404);
            echo json_encode(['error' => 'Match not found']);
            return;
        }
        
        echo json_encode(['success' => true, 'match' => $match]);
    } else {
        $whereConditions = [];
        $params = [];
        
        if ($tournament_id) {
            $whereConditions[] = "m.tournament_id = ?";
            $params[] = $tournament_id;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $stmt = $pdo->prepare("
            SELECT m.*, t.name as tournament_name
            FROM matches m
            LEFT JOIN tournaments t ON m.tournament_id = t.id
            $whereClause
            ORDER BY m.match_date ASC
        ");
        $stmt->execute($params);
        $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'matches' => $matches]);
    }
}

function handleCreateMatch() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $required = ['team1', 'team2', 'match_date'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing required field: $field"]);
            return;
        }
    }
    
    $stmt = $pdo->prepare("
        INSERT INTO matches (
            team1, team2, match_date, tournament_id, 
            status, round, bracket_position
        ) VALUES (?, ?, ?, ?, 'scheduled', ?, ?)
    ");
    
    $stmt->execute([
        $input['team1'],
        $input['team2'],
        $input['match_date'],
        $input['tournament_id'] ?? null,
        $input['round'] ?? 1,
        $input['bracket_position'] ?? 1
    ]);
    
    $matchId = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'match_id' => $matchId,
        'message' => 'Match created successfully'
    ]);
}

function handleUpdateMatch() {
    global $pdo;
    
    $id = $_GET['id'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Match ID required']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Auto-report match scores from game integration
    if (isset($input['score_team1']) && isset($input['score_team2'])) {
        $stmt = $pdo->prepare("
            UPDATE matches 
            SET score_team1 = ?, score_team2 = ?, 
                status = 'completed', completed_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$input['score_team1'], $input['score_team2'], $id]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Match score updated automatically'
        ]);
        return;
    }
    
    $allowedFields = ['status', 'score_team1', 'score_team2', 'winner', 'match_date'];
    $updates = [];
    $params = [];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updates[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'No valid fields to update']);
        return;
    }
    
    $params[] = $id;
    
    $stmt = $pdo->prepare("
        UPDATE matches 
        SET " . implode(', ', $updates) . "
        WHERE id = ?
    ");
    
    $stmt->execute($params);
    
    echo json_encode([
        'success' => true,
        'message' => 'Match updated successfully'
    ]);
}
?>
