<?php
// InfinityFree Optimized Configuration
// Replace your config.php with this content

// InfinityFree Database Configuration
$host = 'sqlXXX.infinityfree.com'; // Replace XXX with your server number
$dbname = 'if0_XXXXXXX_esports'; // Replace with your actual database name
$username = 'if0_XXXXXXX'; // Replace with your actual username
$password = 'your_database_password'; // Replace with your actual password
$port = 3306;

// Disable error reporting for production (InfinityFree requirement)
error_reporting(0);
ini_set('display_errors', 0);

// Create log directory if it doesn't exist
if (!is_dir(__DIR__ . '/logs')) {
    @mkdir(__DIR__ . '/logs', 0755, true);
}

try {
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_PERSISTENT => false, // InfinityFree doesn't support persistent connections
        PDO::ATTR_TIMEOUT => 30, // Set connection timeout
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
    
    // Test connection
    $pdo->query("SELECT 1");
    
    // Connection successful - log it
    error_log("Database connection successful at " . date('Y-m-d H:i:s'), 3, __DIR__ . '/logs/app.log');
    
} catch (PDOException $e) {
    // Log the actual error for debugging
    error_log("Database connection failed: " . $e->getMessage(), 3, __DIR__ . '/logs/error.log');
    
    // Display user-friendly error message
    die("Database connection failed. Please check your database configuration.");
}

// InfinityFree specific settings
ini_set('memory_limit', '64M'); // InfinityFree memory limit
ini_set('max_execution_time', 30); // Execution time limit
ini_set('upload_max_filesize', '10M');
ini_set('post_max_size', '10M');

// Session configuration for InfinityFree
ini_set('session.gc_maxlifetime', 1440);
ini_set('session.cookie_lifetime', 0);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define constants for InfinityFree
define('BASE_URL', 'https://your-subdomain.infinityfreeapp.com'); // Replace with your actual URL
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('LOG_PATH', __DIR__ . '/logs/');

// Create necessary directories
$directories = ['uploads', 'logs', 'cache'];
foreach ($directories as $dir) {
    $fullPath = __DIR__ . '/' . $dir;
    if (!is_dir($fullPath)) {
        @mkdir($fullPath, 0755, true);
    }
}
?>
