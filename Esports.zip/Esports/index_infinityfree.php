<?php
// Simplified Index.php for InfinityFree
// Replace your index.php with this content

// Start output buffering
ob_start();

// Error handling for InfinityFree
error_reporting(0);
ini_set('display_errors', 0);

// Include configuration
require_once 'config.php';

// Simple routing for InfinityFree
$page = $_GET['page'] ?? 'home';
$allowed_pages = ['home', 'tournaments', 'login', 'register', 'dashboard', 'about', 'contact'];

// Sanitize page parameter
$page = preg_replace('/[^a-zA-Z0-9_-]/', '', $page);

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Get user info
function getCurrentUser() {
    global $pdo;
    
    if (!isLoggedIn()) {
        return null;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return null;
    }
}

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($page); ?> - Esports Platform</title>
    
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #0f1419;
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-dark {
            background-color: #1a2332 !important;
        }
        
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 100px 0;
            text-align: center;
        }
        
        .card {
            background-color: #1a2332;
            border: 1px solid #2d3748;
            margin-bottom: 20px;
        }
        
        .btn-primary {
            background-color: #667eea;
            border-color: #667eea;
        }
        
        .btn-primary:hover {
            background-color: #764ba2;
            border-color: #764ba2;
        }
        
        .tournament-card {
            transition: transform 0.3s ease;
        }
        
        .tournament-card:hover {
            transform: translateY(-5px);
        }
        
        .status-badge {
            font-size: 0.8rem;
            padding: 0.25rem 0.5rem;
        }
        
        .footer {
            background-color: #1a2332;
            color: #a0aec0;
            padding: 40px 0;
            margin-top: 80px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="?page=home">
                <i class="fas fa-gamepad"></i> Esports Platform
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="?page=home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?page=tournaments">Tournaments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?page=about">About</a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="?page=dashboard">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($currentUser['username'] ?? 'User'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="?page=login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?page=register">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <?php
        // Include the appropriate page
        switch ($page) {
            case 'home':
                include 'pages/home.php';
                break;
                
            case 'tournaments':
                include 'pages/tournaments.php';
                break;
                
            case 'login':
                include 'pages/login.php';
                break;
                
            case 'register':
                include 'pages/register.php';
                break;
                
            case 'dashboard':
                if (isLoggedIn()) {
                    include 'pages/dashboard.php';
                } else {
                    header('Location: ?page=login');
                    exit;
                }
                break;
                
            case 'about':
                include 'pages/about.php';
                break;
                
            default:
                include 'pages/home.php';
                break;
        }
        ?>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="fas fa-gamepad"></i> Esports Platform</h5>
                    <p>Your ultimate destination for competitive gaming tournaments and esports events.</p>
                </div>
                <div class="col-md-6 text-end">
                    <p>&copy; <?php echo date('Y'); ?> Esports Platform. All rights reserved.</p>
                    <div class="social-links">
                        <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-light me-3"><i class="fab fa-discord"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-twitch"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Simple JavaScript for InfinityFree -->
    <script>
        // Simple form validation
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('.needs-validation');
            
            Array.prototype.slice.call(forms).forEach(function(form) {
                form.addEventListener('submit', function(event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        });
        
        // Show loading spinner
        function showLoading(button) {
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            button.disabled = true;
        }
    </script>
</body>
</html>

<?php
// End output buffering and send content
ob_end_flush();
?>
