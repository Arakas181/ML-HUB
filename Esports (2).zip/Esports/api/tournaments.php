<?php
require_once '../config.php';
session_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// API Key validation
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
$validApiKeys = ['dev_key_123', 'tournament_api_456']; // In production, store in database

if (!in_array($apiKey, $validApiKeys)) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid API key']);
    exit();
}

try {
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            handleGetTournaments();
            break;
        case 'POST':
            handleCreateTournament();
            break;
        case 'PUT':
            handleUpdateTournament();
            break;
        case 'DELETE':
            handleDeleteTournament();
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    error_log('Tournament API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}

function handleGetTournaments() {
    global $pdo;
    
    $id = $_GET['id'] ?? null;
    
    if ($id) {
        // Get specific tournament
        $stmt = $pdo->prepare("
            SELECT t.*, 
                   COUNT(tr.id) as participant_count,
                   GROUP_CONCAT(tr.team_name) as participants
            FROM tournaments t
            LEFT JOIN tournament_registrations tr ON t.id = tr.tournament_id
            WHERE t.id = ?
            GROUP BY t.id
        ");
        $stmt->execute([$id]);
        $tournament = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tournament) {
            http_response_code(404);
            echo json_encode(['error' => 'Tournament not found']);
            return;
        }
        
        echo json_encode(['success' => true, 'tournament' => $tournament]);
    } else {
        // Get tournaments with filters
        $limit = min((int)($_GET['limit'] ?? 50), 100);
        $offset = (int)($_GET['offset'] ?? 0);
        $status = $_GET['status'] ?? '';
        $game = $_GET['game'] ?? '';
        
        $whereConditions = [];
        $params = [];
        
        if ($status) {
            $whereConditions[] = "t.status = ?";
            $params[] = $status;
        }
        
        if ($game) {
            $whereConditions[] = "t.game = ?";
            $params[] = $game;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $stmt = $pdo->prepare("
            SELECT t.*, 
                   COUNT(tr.id) as participant_count
            FROM tournaments t
            LEFT JOIN tournament_registrations tr ON t.id = tr.tournament_id
            $whereClause
            GROUP BY t.id
            ORDER BY t.start_date ASC
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $limit;
        $params[] = $offset;
        $stmt->execute($params);
        $tournaments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'tournaments' => $tournaments]);
    }
}

function handleCreateTournament() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $required = ['name', 'game', 'start_date', 'end_date', 'max_participants'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing required field: $field"]);
            return;
        }
    }
    
    $stmt = $pdo->prepare("
        INSERT INTO tournaments (
            name, description, game, start_date, end_date, 
            max_participants, prize_pool, entry_fee, bracket_type,
            skill_level, region, status, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'upcoming', 1)
    ");
    
    $stmt->execute([
        $input['name'],
        $input['description'] ?? '',
        $input['game'],
        $input['start_date'],
        $input['end_date'],
        $input['max_participants'],
        $input['prize_pool'] ?? 0,
        $input['entry_fee'] ?? 0,
        $input['bracket_type'] ?? 'single_elimination',
        $input['skill_level'] ?? 'mixed',
        $input['region'] ?? 'global'
    ]);
    
    $tournamentId = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'tournament_id' => $tournamentId,
        'message' => 'Tournament created successfully'
    ]);
}

function handleUpdateTournament() {
    global $pdo;
    
    $id = $_GET['id'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Tournament ID required']);
        return;
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $allowedFields = [
        'name', 'description', 'start_date', 'end_date',
        'max_participants', 'prize_pool', 'entry_fee',
        'bracket_type', 'skill_level', 'region', 'status'
    ];
    
    $updates = [];
    $params = [];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updates[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'No valid fields to update']);
        return;
    }
    
    $params[] = $id;
    
    $stmt = $pdo->prepare("
        UPDATE tournaments 
        SET " . implode(', ', $updates) . "
        WHERE id = ?
    ");
    
    $stmt->execute($params);
    
    echo json_encode([
        'success' => true,
        'message' => 'Tournament updated successfully'
    ]);
}

function handleDeleteTournament() {
    global $pdo;
    
    $id = $_GET['id'] ?? null;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Tournament ID required']);
        return;
    }
    
    // Check if tournament has participants
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tournament_registrations WHERE tournament_id = ?");
    $stmt->execute([$id]);
    $participantCount = $stmt->fetchColumn();
    
    if ($participantCount > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Cannot delete tournament with participants']);
        return;
    }
    
    $stmt = $pdo->prepare("DELETE FROM tournaments WHERE id = ?");
    $stmt->execute([$id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Tournament deleted successfully'
    ]);
}
?>
